 # === PARAMETROS ===

        
        $gpoName = "CCN-STIC-570A25_Dominio_AnexoC - Usuarios, Cuentas y Contrase�as (ENS)"
        $gpoPath = "C:\Scripts\ENS\ANEXO C - POLITICAS DE CUENTA Y CONTRASE�A"
        $Domain = (Get-ADDomain).DistinguishedName
               
        $OUPath = "$Domain"
   

        # === CREAR GPO SI NO EXISTE ===
        if (-not (Get-GPO -Name $gpoName -ErrorAction SilentlyContinue)) {
            New-GPO -Name $gpoName | Out-Null
            Write-Host "GPO '$gpoName' creada."`n`
        } else {
            Write-Host "GPO '$gpoName' ya existe."`n`
        }


        # === RESTABLECER BACKUP PARA IMPORTAR CONFIGURACIONES ===

        Write-Host Configurando politica...`n`
        Import-GPO -BackupGPOName "$gpoName" -TargetName $gpoName -Path "$gpoPath" | Out-Null
        Write-Host GPO configurada`n`


        # === VINCULAR A LA OU ===

        if (-not ((Get-GPInheritance -Target $OUPath).GpoLinks | Where-Object {$_.DisplayName -like $gpoName} ))  {
            New-GPLink -Name $gpoName -Target $OUPath -LinkEnabled no -order 1
            Write-Host "GPO vinculada a $OUPath"`n`
        } else {
            Write-Host "GPO ya est� vinculada a $OUPath"`n`
        }
        