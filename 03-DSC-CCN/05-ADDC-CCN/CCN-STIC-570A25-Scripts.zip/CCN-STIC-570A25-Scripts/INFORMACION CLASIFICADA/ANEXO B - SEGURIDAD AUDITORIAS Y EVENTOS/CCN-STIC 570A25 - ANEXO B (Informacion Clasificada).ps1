 # === PARAMETROS ===

        $DCOU = "Domain Controllers"
        $ServersOU = "Servidores"
        
        $gpoDCName = "CCN-STIC-570A25_DC_AnexoB - Seguridad, auditoria y registros (Informacion Clasificada)"
        $gpoServername = "CCN-STIC-570A25_Servidor Miembro_AnexoB - Seguridad, auditoria y registros (Informacion Clasificada)"
        $gpoPath = "C:\Scripts\INFORMACION CLASIFICADA\ANEXO B - SEGURIDAD AUDITORIAS Y EVENTOS"
        $Domain = (Get-ADDomain).DistinguishedName
               
        $DCOUPath = "OU=$DCOU,$Domain"
        $ServidorOUPath = "OU=$ServersOU,$Domain"    

        # === CREAR GPO SI NO EXISTE ===
        if (-not (Get-GPO -Name $gpoDCName -ErrorAction SilentlyContinue)) {
            New-GPO -Name $gpoDCName | Out-Null
            Write-Host "GPO '$gpoDCName' creada."`n`
        } else {
            Write-Host "GPO '$gpoDCName' ya existe."`n`
        }

        if (-not (Get-GPO -Name $gpoServername -ErrorAction SilentlyContinue)) {
            New-GPO -Name $gpoServername | Out-Null
            Write-Host "GPO '$gpoServername' creada."`n`
        } else {
            Write-Host "GPO '$gpoServername' ya existe."`n`
        }

        # === RESTABLECER BACKUP PARA IMPORTAR CONFIGURACIONES ===

        Write-Host Configurando politica...`n`
        Import-GPO -BackupGPOName "$gpoDCName" -TargetName $gpoDCName -Path "$gpoPath" | Out-Null
        Import-GPO -BackupGPOName "$gpoServername" -TargetName $gpoServername -Path "$gpoPath" | Out-Null
        Write-Host GPO configurada`n`


        # === VINCULAR A LA OU ===

        if (-not ((Get-GPInheritance -Target $DCOUPath).GpoLinks | Where-Object {$_.DisplayName -like $gpoDCName} ))  {
            New-GPLink -Name $gpoDCName -Target $DCOUPath -LinkEnabled no -order 1
            Write-Host "GPO vinculada a $DCOUPath"`n`
        } else {
            Write-Host "GPO ya est� vinculada a $DCOUPath"`n`
        }
            if (-not ((Get-GPInheritance -Target $ServidorOUPath).GpoLinks | Where-Object {$_.DisplayName -like $gpoServername} ))  {
            New-GPLink -Name $gpoServername -Target $ServidorOUPath -LinkEnabled no -order 1
            Write-Host "GPO vinculada a $ServidorOUPath"`n`
        } else {
            Write-Host "GPO ya est� vinculada a $ServidorOUPath"`n`
        }