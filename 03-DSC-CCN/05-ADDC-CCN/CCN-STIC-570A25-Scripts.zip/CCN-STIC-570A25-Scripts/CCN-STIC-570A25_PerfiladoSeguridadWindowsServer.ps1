﻿

# === COMPROBAR IDIOMA ===

if ((get-culture).name -like "*es*") {


# === INICIO Y VARIABLES ===
Clear-Host
$RutaScript = "$PSScriptRoot"
$Advertencia = "---ADVERTENCIA---"
$FinAdvertencia = "---FIN ADVERTENCIA---"
$DisclaimerMSG = @'
Este script incorpora modificaciones en el sistema orientadas a la aplicación de medidas de bastionado, conforme a los perfiles de seguridad definidos por el Centro Criptológico Nacional (CCN). Para su correcta aplicación, es imprescindible seguir las recomendaciones establecidas en la guía CCN-STIC-570A25, comprendiendo los riesgos, impactos y acciones asociadas que en ella se detallan.
'@
$anchoConsola = [console]::WindowWidth
$posicion = [Math]::Max(0, ($anchoConsola - $Advertencia.Length) / 2)
$posicion2 = [Math]::Max(0, ($anchoConsola - $FinAdvertencia.Length) / 2)

# === DISCLAIMER ===

Write-Host
Write-Host (' ' * $posicion + $advertencia) -ForegroundColor red
Write-Host $DisclaimerMSG -ForegroundColor Yellow
Write-Host (' ' * $posicion2 + $Finadvertencia) -ForegroundColor red

$DisclaimerConfirmar = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
$Disclaimer = $host.UI.PromptForChoice("¿Desea aceptar los riesgos y continuar con el bastionado del sistema?", "Selecciona una opcion:", $DisclaimerConfirmar, 1)
if ($Disclaimer -ne 0) {Write-Host Saliendo...;exit}


# === COMPROBAR SI ES CONTROLADOR DE DOMINIO Y WINDOWS SERVER 2025 === (Versiones diferentes a Windows Server 2025 excluidas por completo)
if ((Get-CimInstance Win32_OperatingSystem).caption -like "*202*" -and (Get-CimInstance Win32_ComputerSystem).DomainRole -eq 5)
{

Write-Host
Write-Host El servidor es un Windows Server  y contiene el rol de Controlador de Dominio
Write-Host Iniciando configuracion... `n`



# === COMPROBACION Y CREACION DE CARPETAS 

    if (-not ($RutaScript)) {
        Write-Host Error al establecer ruta, es necesario copiar los archivos manualmente en la carpeta c:\Scripts `n`
    }

    if (-not (Test-Path C:\Scripts)){
        Write-Host Creando carpeta Scripts...
        New-item -Path C:\Scripts -ItemType directory | Out-Null
        Write-Host Carpeta preparada
        }

# === CREACION DE UNIDADES ORGANIZATIVAS ===
        
    Write-Host CONFIGURANDO UNIDADES ORGANIZATIVAS`n -ForegroundColor DarkMagenta


        $Domain = (Get-ADDomain).DistinguishedName
        $OUs = @("Servidores","Clientes","Domain Controllers")


        Write-Host Comprobando Unidades Organizativas...
        Write-Host
        foreach ($OU in $OUs)
        {
            Write-Host Comprobando Unidad Organizativa $OU
            $OuName = "OU=$OU,$Domain"
            if (Get-ADOrganizationalUnit -LDAPFilter "(distinguishedName=$OuName)" -ErrorAction SilentlyContinue) 
            {
                Write-Host la Unidad Organizativa $OU existe
                Write-Host ADVERTENCIA: Las GPO de bastionado se aplican a esta Unidad Organizativa. Si no se aplican filtros, todos los objetos dentro de esta OU seran bastionados. -ForegroundColor Yellow
                Write-Host Continuando...`n
            }
            else 
            {
                Write-Host Creando Unidad Organizativa $OU
                New-ADOrganizationalUnit -Name "$OU" -Path "$domain"
                Write-Host Unidad Organizativa creada...`n
            }
        }
    


# === FUNCION PARA ELEGIR ANEXO A BASTIONAR ===
    function Elegir-Bastionado {
        param ()

        $seguir = $true

        while ($seguir) {

            # === MOSTRAR LISTA DE ANEXOS ===

	    $MenuAnexo = [System.Management.Automation.Host.ChoiceDescription[]] @(
         "ANEXO &A",
         "ANEXO &B", 
         "ANEXO &C",
         "ANEXO &D",
         "ANEXO &E",
         "ANEXO &F",
         "ANEXO &G",
         "ANEXO &H",
         "&SALIR"
         )

 
                  
        Write-Host "=============================  LISTA DE ANEXOS  =============================" -ForegroundColor Magenta
        Write-Host "    ANEXO A. Configuración base de Windows." -ForegroundColor Cyan
        Write-Host "    ANEXO B. Políticas de seguridad, auditoría y registros de eventos." -ForegroundColor Cyan
        Write-Host "    ANEXO C. Gestión de usuarios y políticas de cuenta y contraseña." -ForegroundColor Cyan
        Write-Host "    ANEXO D. Seguridad de red y firewall de Windows Defender." -ForegroundColor Cyan
        Write-Host "    ANEXO E. Manejo y control de dispositivos." -ForegroundColor Cyan
        Write-Host "    ANEXO F. Configuración de BitLocker y criptografía." -ForegroundColor Cyan
        Write-Host "    ANEXO G. Acceso mediante escritorio remoto." -ForegroundColor Cyan
        Write-Host "    ANEXO H. Acceso a auditorías mediante Nessus." -ForegroundColor Cyan
        Write-Host "=============================================================================" -ForegroundColor Magenta

         


	    $SeleccionAnexo = $host.UI.PromptForChoice("¿QUE ANEXO DESEA APLICAR?","Seleccione una opcion de la siguientes", $menuAnexo, 8)
	    switch($SeleccionAnexo)
	    {
		    0 {$ANEXO = "ANEXO A"}
		    1 {$ANEXO = "ANEXO B"}
		    2 {$ANEXO = "ANEXO C"}
		    3 {$ANEXO = "ANEXO D"}
		    4 {$ANEXO = "ANEXO E"}
		    5 {$ANEXO = "ANEXO F"}
            6 {$ANEXO = "INCREMENTAL RDP"}
            7 {$ANEXO = "INCREMENTAL NESSUS"}
            8 {exit}
	    }  

            Write-host
            Write-Host "APLICANDO $ANEXO"`n`



          $Script = Get-ChildItem "C:\Scripts\$Grado\$ANEXO*" -directory

          # === EJECUCION DE SCRIPT DE BASTIONADO DE ANEXOS INDEPENDIENTES ===

          & "$Script\CCN-STIC 570A25 - $ANEXO ($Grado).ps1"

            # === PREGUNTAR CONTINUACION ===
            $MenuConfirmacion = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
            $confirmar = $host.UI.PromptForChoice("¿Desea Continuar aplicando otro Anexo?", "Selecciona una opcion:", $MenuConfirmacion, 0)

            if ($confirmar -ne 0) {
                $seguir = $false
                Write-Host "Saliendo del script..."
            }
        }
    }

    function Elegir-grado {

    param ()

        Write-Host Configurando CIS para el perfil de $Grado
        if (Test-Path C:\Scripts\$Grado) 
                {
                    Write-Host Existe una carpeta de bastionado en la ruta C:\Scripts\$Grado, por favor, revise previamente si es correcta, antes de continuar.
                    Write-Host "ADVERTENCIA: Si continua la carpeta actual sera sustituida por completo por la carpeta de bastionado.`n" -ForegroundColor Yellow
                    $ConfirmarEliminacion = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
                    $Eliminacion = $host.UI.PromptForChoice("¿Desea Continuar?", "", $ConfirmarEliminacion, 1)
                    if ($Eliminacion -ne 0) {
                        Write-Host "Saliendo del script..."
                        exit
                    }
                    elseif ($Eliminacion -eq 0) {
                        Write-Host Reemplazando archivos de bastionado...
                        Remove-Item -Path C:\Scripts\$grado -Force -Recurse
                        Copy-Item -Path $RutaScript\$grado -Destination c:\Scripts -Recurse
                        Write-Host Archivos Reemplazados`n`
                    }

            }
        else 
        {
    
            Write-Host Copiando archivos de bastionado...
            Copy-Item -Path $RutaScript\$grado -Destination c:\Scripts -Recurse
            Write-Host Archivos copiados`n`
    
        }
    }
# === SELECCIONAR PERFIL DE CALIFICACION ===

    $Pregunta = "ELIJA EL PERFIL DE CLASIFICACION DE LA INFORMACION QUE VA A CONTENER EL SISTEMA"
    $MenuGrado = [System.Management.Automation.Host.ChoiceDescription[]] @("&ENS", "&DIFUSION LIMITADA", "&INFORMACION CLASIFICADA")
    $default = 0
    $SeleccionGrado = $host.UI.PromptForChoice("$Pregunta","Seleccione una opcion", $menuGrado, $default)
    switch($SeleccionGrado)
    {
	    0 {
            $Grado = "ENS"
            Elegir-grado
	    }
	    1 {
            $Grado = "DIFUSION LIMITADA"
		    Elegir-grado
	    }

	    2 {
            $Grado = "INFORMACION CLASIFICADA"
		    Elegir-grado
           }
            }

    # === EJECUCION DE SCRIPTS ===

    if ($Grado -like "INFORMACION CLASIFICADA")
    {

        Write-Host "INCREMENTAL GRADO SECRETO" -ForegroundColor Yellow `n
        $ElegirSecreto = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
        $confirmar = $host.UI.PromptForChoice("¿DESEA APLICAR EL BASTIONADO PARA GRADO SECRETO?", "Selecciona una opcion:", $ElegirSecreto, 1)

        if ($confirmar -eq 0) 
        {
            & "C:\Scripts\INFORMACION CLASIFICADA\INCREMENTAL SECRETO\CCN-STIC 570A25 - Incremental Secreto.ps1"
            Elegir-Bastionado
        }
        if ($confirmar -eq 1) 
        {
            Elegir-Bastionado
        }

                

    }
    else 
    {
        Elegir-Bastionado
    }

}


# === REVISAR CONDICIONES === (Server 2025 y servidor miembro)
elseif ((Get-CimInstance Win32_OperatingSystem).caption -like "*202*" -and (Get-CimInstance Win32_ComputerSystem).DomainRole -eq 3)
{

Write-Host El servidor es un Windows Server 2025 y es un servidor miembro de dominio. Iniciando configuracion...`n

Import-Module ServerManager
# === COMPROBACION Y CREACION DE CARPETAS 


    if (-not ($RutaScript)) {
        Write-Host Error al establecer ruta, es necesario copiar los archivos manualmente en la carpeta c:\Scripts `n`
    }

    if (-not (Test-Path C:\Scripts)){
        Write-Host Creando carpeta Scripts...
        New-item -Path C:\Scripts -ItemType directory | Out-Null
        Write-Host Carpeta preparada
        }

        $seguir = $true

        while ($seguir) {

            # === MOSTRAR LISTA DE ANEXOS ===

	        $MenuAnexo = [System.Management.Automation.Host.ChoiceDescription[]] @("ANEXO &A","ANEXO &E","&SALIR")
	        $SeleccionAnexo = $host.UI.PromptForChoice("¿QUE ANEXO DESEA APLICAR?","Seleccione una opcion de la siguientes", $menuAnexo, 0)
	        switch($SeleccionAnexo)
	        {
		    0 
            {
                $ANEXO = "ANEXO A"
                Write-Host "Aplicando $ANEXO"


                # === ROLES Y CARACTERISTICAS A MANTENER ===
                    # Si se necesita mantener un rol especifico, añadir en el array "$mantener_rol"


                $mantener_rol = @(
                    "FileAndStorage-Services",
	                "Storage-Services",
                    "File-Services",
                    "FS-FileServer",
                    "AD-Domain-Services",
                    "DNS",   
                    "NET-Framework-45-Features",
                    "NET-Framework-45-Core",
                    "NET-WCF-Services45",
                    "NET-WCF-TCP-PortSharing45",
                    "GPMC",
                    "Windows-Defender",
                    "System-DataArchiver",
                    "BitLocker",
                    "WoW64-Support",
                    "Windows-Server-Backup",
                    "EnhancedStorage",
                    "RSAT",
                    "RSAT-Feature-Tools",
                    "RSAT-Feature-Tools-BitLocker",
                    "RSAT-Feature-Tools-BitLocker-RemoteAdminTool",
                    "RSAT-Feature-Tools-BitLocker-BdeAducExt",
                    "RSAT-Role-Tools",
                    "RSAT-AD-Tools",
                    "RSAT-ADDS",
                    "RSAT-AD-AdminCenter",
                    "RSAT-ADDS-Tools",
                    "RSAT-AD-PowerShell",
                    "RSAT-DNS-Server",
                    "PowerShellRoot",
                    "PowerShell",
                    "PowerShell-ISE",
                    "User-Interfaces-Infra",
                    "Server-Gui-Mgmt-Infra",
                    "Server-Gui-Shell",
                    "FS-SMB1"
                )


                 # === VARIABLES Y FICHEROS ===
                $CaracteristicasHabilitadas = @()
                $FicheroCaracteristicas = "C:\Scripts\CCN-STIC-570A25_Caracteristicas Deshabilitadas.csv"
                Add-Content -Value "NombreCaracteristica!Caracteristica!TipoCaracteristica" -path $FicheroCaracteristicas


                # === LISTAR CARACTERISTICAS ===
                Write-Host “ROLES Y CARACTERISTICAS INSTALADOS EN EL EQUIPO`n" -ForegroundColor DarkMagenta

                $CaracteristicasHabilitadas = Get-WindowsFeature | where-object {$_.Installed} | select-object displayname,name,featuretype | sort DisplayName
                $CaracteristicasHabilitadas | Out-Default



                # === PREGUNTAR CONTINUACION ===

                Write-Host Se van a deshabilitar caracteristicas y roles del sistema.`n
                Write-Host ADVERTENCIA: El script contempla las caracteristicas y roles mínimos necesarios y los mantiene.`n -ForegroundColor Yellow
                

                        $MenuConfirmacionCaracteristica = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
                        $confirmarCaracteristicas = $host.UI.PromptForChoice("¿Desea continuar la eliminación de las caracteristicas y roles?", "Selecciona una opcion:", $MenuConfirmacionCaracteristica, 0)

                        if ($confirmarCaracteristicas -ne 0) {
                            Write-Host "Saliendo del script..."
                            exit
                        }


                # === DESHABILITAR ROLES NO EXCLUIDOS ===
                foreach ($Caracteristica in $CaracteristicasHabilitadas ) {
	                if ($mantener_rol -notcontains $Caracteristica.Name)	{
                        Clear-Host
		                Write-Host "Deshabilitando caracteristica: "$Caracteristica.Name""
		                Uninstall-WindowsFeature -Name $Caracteristica.Name
                        $Caracteristica.Name + "!" + $Caracteristica.DisplayName + "!" + $Caracteristica.FeatureType| Add-Content $FicheroCaracteristicas
	                }
                }

                Write-Host Caracteristicas y roles deshabilitados correctamente.
                Write-Host "Puede consultar un registro de las caracteristicas deshabilitadas en el fichero C:\Scripts\CCN-STIC-570A25_Caracteristicas Deshabilitadas.csv"
   
                # === PREGUNTAR CONTINUACION ===
                $MenuConfirmacion = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
                $confirmar = $host.UI.PromptForChoice("¿Desea Continuar aplicando otro Anexo?", "Selecciona una opcion:", $MenuConfirmacion, 0)

                if ($confirmar -ne 0) {
                    $seguir = $false
                    Write-Host "Saliendo del script..."


            }
            }
		    1 
            {


                $ANEXO = "ANEXO E"
                Write-Host "Aplicando Anexo E"

                # === HABILITAR REGISTROS CONEXIONES USB ===
                $eventosusb = Get-WinEvent -ListLog 'Microsoft-Windows-DriverFrameworks-UserMode/Operational'
                $eventosusb.IsEnabled = $true
                $eventosusb.SaveChanges()

                Write-Host Registro de conexiones USB habilitado.´n

                # === PREGUNTAR CONTINUACION ===
                $MenuConfirmacion = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
                $confirmar = $host.UI.PromptForChoice("¿Desea Continuar la aplicacion de otro Anexo?", "Selecciona una opcion:", $MenuConfirmacion, 0)

                if ($confirmar -ne 0) {
                    $seguir = $false
                    Write-Host "Saliendo del script..."

                }
            }
            2 {exit}
	      

            
        }



        }









}

else {
Write-Host El equipo no cumple con los requisitos de bastionado, por favor, revise la version y las caracteristicas del equipo para poder continuar...
Write-Host Saliendo del script...
exit
}


}



# === CHECK LANGUAGE


elseif ((Get-Culture).name -like "*en*"){



# === STARTS AND VARIABLES ===
Clear-Host
$RutaScript = "$PSScriptRoot"
$Advertencia = "---WARNING---"
$FinAdvertencia = "---END WARNING---"
$DisclaimerMSG = @'
This script incorporates modifications in the system aimed at applying hardening measures, in accordance with the security profiles defined by Centro Criptologico Nacional (CCN). For proper application, it is essential to follow the recommendations established in the CCN-STIC-570A25 guide, understanding the risks, impacts, and associated actions detailed therein.
'@
$anchoConsola = [console]::WindowWidth
$posicion = [Math]::Max(0, ($anchoConsola - $Advertencia.Length) / 2)
$posicion2 = [Math]::Max(0, ($anchoConsola - $FinAdvertencia.Length) / 2)

# === DISCLAIMER ===

Write-Host
Write-Host (' ' * $posicion + $advertencia) -ForegroundColor red
Write-Host $DisclaimerMSG -ForegroundColor Yellow
Write-Host (' ' * $posicion2 + $Finadvertencia) -ForegroundColor red

$DisclaimerConfirmar = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
$Disclaimer = $host.UI.PromptForChoice("Do you want to accept the risks and continue with the system hardening?", "Select an option:", $DisclaimerConfirmar, 1)
if ($Disclaimer -ne 0) {Write-Host Saliendo...;exit}


# === CHECK IF IT IS A DOMAIN CONTROLLER AND WINDOWS SERVER 2025 === (Versions other than Windows Server 2025 completely excluded)
if ((Get-CimInstance Win32_OperatingSystem).caption -like "*202*" -and (Get-CimInstance Win32_ComputerSystem).DomainRole -eq 5)
{

Write-Host
Write-Host The server is a Windows Server 2025 and contains the Domain Controller role.
Write-Host Starting Configuration... `n`



# === CHECKING AND CREATING FOLDERS === 

    if (-not ($RutaScript)) {
        Write-Host Error setting path, it is necessary to manually copy the files into the folder c:\Scripts `n`
    }

    if (-not (Test-Path C:\Scripts)){
        Write-Host Creating folder Scripts...
        New-item -Path C:\Scripts -ItemType directory | Out-Null
        Write-Host Folder creation finished `n
        }

# === OU CREATION ===
        
    Write-Host SETTING UP ORGANIZATIONAL UNITS`n


        $Domain = (Get-ADDomain).DistinguishedName
        $OUs = @("Servidores","Clientes","Domain Controllers")


        Write-Host Checking Organizational Units...
        Write-Host
        foreach ($OU in $OUs)
        {
            Write-Host Checking Organizational Unit $OU
            $OuName = "OU=$OU,$Domain"
            if (Get-ADOrganizationalUnit -LDAPFilter "(distinguishedName=$OuName)" -ErrorAction SilentlyContinue) 
            {
                Write-Host Organitazional Unit $OU exists
                Write-Host WARNING: The hardening GPOs are applied to this Organizational Unit. If no filters are applied, all objects within this OU will be hardened. -ForegroundColor Yellow
                Write-Host Continuing...`n
            }
            else 
            {
                Write-Host Creating Organizational Unit $OU
                New-ADOrganizationalUnit -Name "$OU" -Path "$domain"
                Write-Host Organizational Unit created...`n
            }
        }
    


# === FUNCTION TO CHOOSE ANNEX TO HARDEN ===
    function Elegir-Bastionado {
        param ()

        $seguir = $true

        while ($seguir) {

            # === MOSTRAR LISTA DE ANEXOS ===


	    $MenuAnexo = [System.Management.Automation.Host.ChoiceDescription[]] @(
         "ANEXO &A",
         "ANEXO &B", 
         "ANEXO &C",
         "ANEXO &D",
         "ANEXO &E",
         "ANEXO &F",
         "ANEXO &G",
         "ANEXO &H",
         "&SALIR"
         )

                  
        Write-Host "=============================  LISTA DE ANEXOS  =============================" -ForegroundColor Magenta
        Write-Host "    ANEXO A. Configuración base de Windows." -ForegroundColor Cyan
        Write-Host "    ANEXO B. Políticas de seguridad, auditoría y registros de eventos." -ForegroundColor Cyan
        Write-Host "    ANEXO C. Gestión de usuarios y políticas de cuenta y contraseña." -ForegroundColor Cyan
        Write-Host "    ANEXO D. Seguridad de red y firewall de Windows Defender." -ForegroundColor Cyan
        Write-Host "    ANEXO E. Manejo y control de dispositivos." -ForegroundColor Cyan
        Write-Host "    ANEXO F. Configuración de BitLocker y criptografía." -ForegroundColor Cyan
        Write-Host "    ANEXO G. Acceso mediante escritorio remoto." -ForegroundColor Cyan
        Write-Host "    ANEXO H. Acceso a auditorías mediante Nessus." -ForegroundColor Cyan
        Write-Host "=============================================================================" -ForegroundColor Magenta

	    $SeleccionAnexo = $host.UI.PromptForChoice("Which annex do you want to harden?","Select an option from the following", $menuAnexo, 0)
	    switch($SeleccionAnexo)
	    {
		    0 {$ANEXO = "ANEXO A"}
		    1 {$ANEXO = "ANEXO B"}
		    2 {$ANEXO = "ANEXO C"}
		    3 {$ANEXO = "ANEXO D"}
		    4 {$ANEXO = "ANEXO E"}
		    5 {$ANEXO = "ANEXO F"}
            6 {$ANEXO = "INCREMENTAL RDP"}
            7 {$ANEXO = "INCREMENTAL NESSUS"}
            8 {exit}
	    }  

            Write-host
            Write-Host "APPLYING $ANEXO"`n`


          $Script = Get-ChildItem "C:\Scripts\$Grado\$ANEXO*" -directory

          # === EXECUTION OF INDEPENDENT ANNEX HARDENING SCRIPT === "

          & "$Script\CCN-STIC 570A25 - $ANEXO ($Grado).ps1"

            # === ASK TO CONTINUE ===
            $MenuConfirmacion = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
            $confirmar = $host.UI.PromptForChoice("Do you want to continue hardening another annex?", "Select an option:", $MenuConfirmacion, 0)

            if ($confirmar -ne 0) {
                $seguir = $false
                Write-Host "Exiting script..."
            }
        }
    }

    function Elegir-grado {

    param ()

        Write-Host Setting Up CIS to $Grado profile
        if (Test-Path C:\Scripts\$Grado) 
                {
                    Write-Host A hardening folder exists at the path C:\Scripts\$Grado, Please check first if it is correct before continuing.
                    Write-Host "WARNING: If you continue, the current folder will be completely replaced by the hardening folder.`n" -ForegroundColor Yellow
                    $ConfirmarEliminacion = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
                    $Eliminacion = $host.UI.PromptForChoice("¿Desea Continuar?", "", $ConfirmarEliminacion, 1)
                    if ($Eliminacion -ne 0) {
                        Write-Host "Exiting script..."
                        exit
                    }
                    elseif ($Eliminacion -eq 0) {
                        Write-Host Replacing hardening files...
                        Remove-Item -Path C:\Scripts\$grado -Force -Recurse
                        Copy-Item -Path $RutaScript\$grado -Destination c:\Scripts -Recurse
                        Write-Host Files Replaced`n`
                    }

            }
        else 
        {
    
            Write-Host Copying hardening files...
            Copy-Item -Path $RutaScript\$grado -Destination c:\Scripts -Recurse
            Write-Host Hardening files copied`n`
    
        }
    }
# === SELECT QUALIFICATION PROFILE ===

    $Pregunta = "CHOOSE THE CLASIFICATION PROFILE FOR THE INFORMATION THE SYSTEM WILL CONTAIN"
    $MenuGrado = [System.Management.Automation.Host.ChoiceDescription[]] @("&ENS", "&DIFUSION LIMITADA", "&INFORMACION CLASIFICADA")
    $default = 0
    $SeleccionGrado = $host.UI.PromptForChoice("$Pregunta","Select an option", $menuGrado, $default)
    switch($SeleccionGrado)
    {
	    0 {
            $Grado = "ENS"
            Elegir-grado
	    }
	    1 {
            $Grado = "DIFUSION LIMITADA"
		    Elegir-grado
	    }

	    2 {
            $Grado = "INFORMACION CLASIFICADA"
		    Elegir-grado
           }
            }

    # === SCRIPT EJECUTION ===

    if ($Grado -like "INFORMACION CLASIFICADA")
    {
        Write-Host "INCREMENTAL SECRET LEVEL" -ForegroundColor Yellow `n
        $ElegirSecreto = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
        $confirmar = $host.UI.PromptForChoice("DO YOU WANT TO APPLY THE HARDENING FOR SECRET LEVEL?", "Choose an option:", $ElegirSecreto, 1)

        if ($confirmar -eq 0) 
        {
            & "C:\Scripts\INFORMACION CLASIFICADA\INCREMENTAL SECRETO\CCN-STIC 570A25 - Incremental Secreto.ps1"
            Elegir-Bastionado
        }
        if ($confirmar -eq 1) 
        {
            Elegir-Bastionado
        }


    }
    else 
    {
        Elegir-Bastionado
    }
}


# === CHECK CONDITIONS === (Server 2025 And Member Server)
elseif ((Get-CimInstance Win32_OperatingSystem).caption -like "*202*" -and (Get-CimInstance Win32_ComputerSystem).DomainRole -eq 3)
{

Write-Host The server is a Windows Server 2025 and is a domain member server. Starting configuration...`n

Import-Module ServerManager
# === CHECKING AND CREATING FOLDERS ===


    if (-not ($RutaScript)) {
        Write-Host Error setting path, it is necessary to manually copy the files into c:\Scripts folder`n`
    }

    if (-not (Test-Path C:\Scripts)){
        Write-Host Creating Script folder...
        New-item -Path C:\Scripts -ItemType directory | Out-Null
        Write-Host Folder prepared
        }

        $seguir = $true

        while ($seguir) {

            # === SHOW ANNEX LIST ===

	        $MenuAnexo = [System.Management.Automation.Host.ChoiceDescription[]] @("ANEXO &A","ANEXO &E","&SALIR")
	        $SeleccionAnexo = $host.UI.PromptForChoice("Which annex do you want to harden?","Select an option from the following", $menuAnexo, 0)
	        switch($SeleccionAnexo)
	        {
		    0 
            {
                $ANEXO = "ANEXO A"
                Write-Host "Applying $ANEXO"


                # === ROLES AND FEATURES TO MAINTAIN ===
                    # If a specific role needs to be maintained, add it to the "$mantener_rol array "


                $mantener_rol = @(
                    "FileAndStorage-Services",
	                "Storage-Services",
                    "File-Services",
                    "FS-FileServer",
                    "AD-Domain-Services",
                    "DNS",   
                    "NET-Framework-45-Features",
                    "NET-Framework-45-Core",
                    "NET-WCF-Services45",
                    "NET-WCF-TCP-PortSharing45",
                    "GPMC",
                    "Windows-Defender",
                    "System-DataArchiver",
                    "BitLocker",
                    "WoW64-Support",
                    "Windows-Server-Backup",
                    "EnhancedStorage",
                    "RSAT",
                    "RSAT-Feature-Tools",
                    "RSAT-Feature-Tools-BitLocker",
                    "RSAT-Feature-Tools-BitLocker-RemoteAdminTool",
                    "RSAT-Feature-Tools-BitLocker-BdeAducExt",
                    "RSAT-Role-Tools",
                    "RSAT-AD-Tools",
                    "RSAT-ADDS",
                    "RSAT-AD-AdminCenter",
                    "RSAT-ADDS-Tools",
                    "RSAT-AD-PowerShell",
                    "RSAT-DNS-Server",
                    "PowerShellRoot",
                    "PowerShell",
                    "PowerShell-ISE",
                    "User-Interfaces-Infra",
                    "Server-Gui-Mgmt-Infra",
                    "Server-Gui-Shell",
                    "FS-SMB1"
                )


                 # === VARIABLES AND FILES ===
                $CaracteristicasHabilitadas = @()
                $FicheroCaracteristicas = "C:\Scripts\CCN-STIC-570A25_Caracteristicas Deshabilitadas.csv"
                Add-Content -Value "NombreCaracteristica!Caracteristica!TipoCaracteristica" -path $FicheroCaracteristicas


                # === LIST FEATURES ===
                Write-Host “ROLES AND FEATURES INSTALLED ON THE MACHINE`n" -ForegroundColor DarkMagenta

                $CaracteristicasHabilitadas = Get-WindowsFeature | where-object {$_.Installed} | select-object displayname,name,featuretype | sort DisplayName
                $CaracteristicasHabilitadas | Out-Default



                # === ASK TO CONTINUE ===

                Write-Host System features and roles are going to be disabled.`n
                Write-Host WARNING: The script considers and maintains only the minimum required features and roles.`n -ForegroundColor Yellow
                

                        $MenuConfirmacionCaracteristica = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
                        $confirmarCaracteristicas = $host.UI.PromptForChoice("Do you want to continue with the removal of the features and roles?", "Select an option:", $MenuConfirmacionCaracteristica, 0)

                        if ($confirmarCaracteristicas -ne 0) {
                            Write-Host "exiting script..."
                            exit
                        }


                # === DISABLE NON-EXCLUDED ROLES ===
                foreach ($Caracteristica in $CaracteristicasHabilitadas ) {
	                if ($mantener_rol -notcontains $Caracteristica.Name)	{
                        Clear-Host
		                Write-Host "Disabling feature: "$Caracteristica.Name""
		                Uninstall-WindowsFeature -Name $Caracteristica.Name
                        $Caracteristica.Name + "!" + $Caracteristica.DisplayName + "!" + $Caracteristica.FeatureType| Add-Content $FicheroCaracteristicas
	                }
                }

                Write-Host Features and roles disabled.
                Write-Host "You can check a log of the disabled features in the C:\Scripts\CCN-STIC-570A25_Caracteristicas Deshabilitadas.csv file"
   
                # === ASK CONTINUE ===
                $MenuConfirmacion = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
                $confirmar = $host.UI.PromptForChoice("Do you want to continue hardening another annex?", "Select an option:", $MenuConfirmacion, 0)

                if ($confirmar -ne 0) {
                    $seguir = $false
                    Write-Host "exiting script..."


            }
            }
		    1 
            {


                $ANEXO = "ANEXO E"
                Write-Host "Applying Anexo E"

                # === ENABLE USB CONNECTION LOGS ===
                $eventosusb = Get-WinEvent -ListLog 'Microsoft-Windows-DriverFrameworks-UserMode/Operational'
                $eventosusb.IsEnabled = $true
                $eventosusb.SaveChanges()

                Write-Host USB connection logging enabled.´n

                # === ASK CONTINUE ===
                $MenuConfirmacion = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
                $confirmar = $host.UI.PromptForChoice("Do you want to continue hardening another annex?", "Select an option:", $MenuConfirmacion, 0)

                if ($confirmar -ne 0) {
                    $seguir = $false
                    Write-Host "exiting script..."

                }
            }
            2 {exit}
	      

            
        }



        }


}

else {
Write-Host El equipo no cumple con los requisitos de bastionado, por favor, revise la version y las caracteristicas del equipo para poder continuar...
Write-Host Saliendo del script...
exit
}


}


Else {Write-Host El sistema debe estar en ingles o en español}