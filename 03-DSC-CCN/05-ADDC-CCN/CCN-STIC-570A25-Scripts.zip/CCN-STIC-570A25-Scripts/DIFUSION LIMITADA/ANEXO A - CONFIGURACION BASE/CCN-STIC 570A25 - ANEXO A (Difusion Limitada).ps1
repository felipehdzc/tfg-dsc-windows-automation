 # === PARAMETROS ===

        $DCOU = "Domain Controllers"
        $ServersOU = "Servidores"
        
        $gpoDCName = "CCN-STIC-570A25_DC_AnexoA - ADMX (Difusion Limitada)"
        $gpoServername = "CCN-STIC-570A25_Servidor Miembro_AnexoA - ADMX (Difusion Limitada)"
        $gpoPath = "C:\Scripts\DIFUSION LIMITADA\ANEXO A - CONFIGURACION BASE"
        $Domain = (Get-ADDomain).DistinguishedName
               
        $DCOUPath = "OU=$DCOU,$Domain"
        $ServidorOUPath = "OU=$ServersOU,$Domain"    

        # === CREAR GPO SI NO EXISTE ===
        if (-not (Get-GPO -Name $gpoDCName -ErrorAction SilentlyContinue)) {
            New-GPO -Name $gpoDCName | Out-Null
            Write-Host "GPO '$gpoDCName' creada."`n`
        } else {
            Write-Host "GPO '$gpoDCName' ya existe."`n`
        }

        if (-not (Get-GPO -Name $gpoServername -ErrorAction SilentlyContinue)) {
            New-GPO -Name $gpoServername | Out-Null
            Write-Host "GPO '$gpoServername' creada."`n`
        } else {
            Write-Host "GPO '$gpoServername' ya existe."`n`
        }

        # === RESTABLECER BACKUP PARA IMPORTAR CONFIGURACIONES ===

        Write-Host Configurando politica...`n`
        Import-GPO -BackupGPOName "$gpoDCName" -TargetName $gpoDCName -Path "$gpoPath" | Out-Null
        Import-GPO -BackupGPOName "$gpoServername" -TargetName $gpoServername -Path "$gpoPath" | Out-Null
        Write-Host GPO configurada`n`


        # === VINCULAR A LA OU ===

        if (-not ((Get-GPInheritance -Target $DCOUPath).GpoLinks | Where-Object {$_.DisplayName -like $gpoDCName} ))  {
            New-GPLink -Name $gpoDCName -Target $DCOUPath -LinkEnabled no -order 1
            Write-Host "GPO vinculada a $DCOUPath"`n`
        } else {
            Write-Host "GPO ya est  vinculada a $DCOUPath"`n`
        }
            if (-not ((Get-GPInheritance -Target $ServidorOUPath).GpoLinks | Where-Object {$_.DisplayName -like $gpoServername} ))  {
            New-GPLink -Name $gpoServername -Target $ServidorOUPath -LinkEnabled no -order 1
            Write-Host "GPO vinculada a $ServidorOUPath"`n`
        } else {
            Write-Host "GPO ya est  vinculada a $ServidorOUPath"`n`
        }

 # === ROLES Y CARACTERISTICAS A MANTENER ===
                    # Si se necesita mantener un rol especifico, a adir en el array "$mantener_rol"


                $mantener_rol = @(
                    "FileAndStorage-Services",
	                "Storage-Services",
                    "File-Services",
                    "FS-FileServer",
                    "AD-Domain-Services",
                    "DNS",   
                    "NET-Framework-45-Features",
                    "NET-Framework-45-Core",
                    "NET-WCF-Services45",
                    "NET-WCF-TCP-PortSharing45",
                    "GPMC",
                    "Windows-Defender",
                    "System-DataArchiver",
                    "BitLocker",
                    "WoW64-Support",
                    "Windows-Server-Backup",
                    "EnhancedStorage",
                    "RSAT",
                    "RSAT-Feature-Tools",
                    "RSAT-Feature-Tools-BitLocker",
                    "RSAT-Feature-Tools-BitLocker-RemoteAdminTool",
                    "RSAT-Feature-Tools-BitLocker-BdeAducExt",
                    "RSAT-Role-Tools",
                    "RSAT-AD-Tools",
                    "RSAT-ADDS",
                    "RSAT-AD-AdminCenter",
                    "RSAT-ADDS-Tools",
                    "RSAT-AD-PowerShell",
                    "RSAT-DNS-Server",
                    "PowerShellRoot",
                    "PowerShell",
                    "PowerShell-ISE",
                    "User-Interfaces-Infra",
                    "Server-Gui-Mgmt-Infra",
                    "Server-Gui-Shell",
                    "FS-SMB1"
                )


                 # === VARIABLES Y FICHEROS ===
                $CaracteristicasHabilitadas = @()
                $FicheroCaracteristicas = "C:\Scripts\CCN-STIC-570A25_Caracteristicas Deshabilitadas.csv"
                Add-Content -Value "NombreCaracteristica!Caracteristica!TipoCaracteristica" -path $FicheroCaracteristicas


                # === LISTAR CARACTERISTICAS ===
                Write-Host  ROLES Y CARACTERISTICAS INSTALADOS EN EL EQUIPO`n -ForegroundColor DarkMagenta

                $CaracteristicasHabilitadas = Get-WindowsFeature | where-object {$_.Installed} | select-object displayname,name,featuretype | sort DisplayName
                $CaracteristicasHabilitadas | Out-Default



                # === PREGUNTAR CONTINUACION ===

                Write-Host Se van a deshabilitar caracteristicas y roles del sistema.`n
                Write-Host "ADVERTENCIA: El script contempla las caracteristicas y roles m�nimos necesarios y los mantiene.`n" -ForegroundColor Yellow
                
                
                
                $MenuConfirmacionCaracteristica = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
                $confirmarCaracteristicas = $host.UI.PromptForChoice(" Desea continuar deshabilitando las caracteristicas y roles?", "Selecciona una opcion:", $MenuConfirmacionCaracteristica, 0)

                if ($confirmarCaracteristicas -ne 0) {
                    Write-Host "Saliendo del script..."
                    exit
                }



                # === DESHABILITAR ROLES NO EXCLUIDOS ===
                foreach ($Caracteristica in $CaracteristicasHabilitadas ) {
	                if ($mantener_rol -notcontains $Caracteristica.Name)	{
                        Clear-Host
		                Write-Host "Deshabilitando caracteristica: "$Caracteristica.Name""
		                Uninstall-WindowsFeature -Name $Caracteristica.Name
                        $Caracteristica.Name + "!" + $Caracteristica.DisplayName + "!" + $Caracteristica.FeatureType| Add-Content $FicheroCaracteristicas
	                }
                }

                Write-Host Caracteristicas y roles deshabilitados correctamente.
                Write-Host "Puede consultar un registro de las caracteristicas deshabilitadas en el fichero C:\Scripts\CCN-STIC-570A25_Caracteristicas Deshabilitadas.csv"