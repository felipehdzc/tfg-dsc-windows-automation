﻿

# === COMPROBAR IDIOMA ===

if ((get-culture).name -like "*es*") {


# === INICIO Y VARIABLES ===
Clear-Host
$Accion = $null
$RutaScript = "$PSScriptRoot"
$Advertencia = "---ADVERTENCIA---"
$FinAdvertencia = "---FIN ADVERTENCIA---"
$DisclaimerMSG = @'
Este script permite realizar una copia de seguridad así como revertir determinadas configuraciones aplicadas durante el proceso de bastionado, facilitando la resolución de incidencias derivadas del mismo. Para garantizar su correcta utilización y minimizar posibles impactos en el sistema, es imprescindible seguir las directrices establecidas en la guía CCN-STIC correspondiente, así como comprender los efectos que su ejecución puede tener sobre el entorno operativo.
'@
$anchoConsola = [console]::WindowWidth
$posicion = [Math]::Max(0, ($anchoConsola - $Advertencia.Length) / 2)
$posicion2 = [Math]::Max(0, ($anchoConsola - $FinAdvertencia.Length) / 2)

# === DISCLAIMER ===

Write-Host
Write-Host (' ' * $posicion + $advertencia) -ForegroundColor red
Write-Host $DisclaimerMSG -ForegroundColor Yellow
Write-Host (' ' * $posicion2 + $Finadvertencia) -ForegroundColor red


# === MENU IMPORTAR/EXPORTAR ===

$ExportImportConfirmar = [System.Management.Automation.Host.ChoiceDescription[]] @("&EXPORTAR","&IMPORTAR","&SALIR")
$ExportImport = $host.UI.PromptForChoice("¿Desea exportar la configuracion actual o importar la guardada?", "Selecciona una opcion:", $ExportImportConfirmar, 2)
if ($ExportImport -eq 0) 
{
    Write-Host Preparando copia de seguridad prebastioando...
    $Accion = "EXPORTAR"
}
elseif ($ExportImport -eq 1) 
{
    Write-Host Restableciendo copia de seguridad prebastioando...
    $Accion = "IMPORTAR"
}
elseif ($ExportImport -eq 2) 
{
    Write-Host Saliendo...
    exit
}


$ExportImportAsegurarConfirmar = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
$ExportImportAsegurar = $host.UI.PromptForChoice("¿Esta seguro de que desea $Accion la configuracion", "Selecciona una opcion:", $ExportImportAsegurarConfirmar, 1)
if ($ExportImportAsegurar -eq 0) 
{
    Write-Host Iniciando $Accion de la configuracion...
    Write-Host

    if ($Accion -eq "EXPORTAR")
    {



    # === COMPROBAR Y CREAR CARPETAS === 

        if (-not (Test-Path C:\Scripts)){
            Write-Host Creando carpeta Scripts...`n
            New-item -Path C:\Scripts -ItemType directory | Out-Null
            Write-Host Carpeta preparada`n
        }
       

        if (Test-Path C:\Scripts\REGRESION) 
        {
            Write-Host Existe una carpeta de regresion en la ruta C:\Scripts\REGRESION, por favor, si desea volver a guardar la configuracion del sistema es necesario que guarde esta carpeta en un sitio seguro o la renombre.
            Write-Host ADVERTENCIA: No podrá continuar el proceso de exportacion si la carpeta se encuentra en la ruta actual.
            write-Host Saliendo...
            exit
        }
        else 
        {
            Write-Host Copiando archivos de bastionado... `n
            Copy-Item -Path $RutaScript\REGRESION -Destination c:\Scripts -Recurse
            Write-Host Archivos copiados `n
        }


        # === CREAR OU Y GPO DE REGRESIVA ===


        if ((Get-CimInstance Win32_OperatingSystem).caption -like "*202*" -and (Get-CimInstance Win32_ComputerSystem).DomainRole -eq 5)

        {

            $DCOU = "Domain Controllers_regresiva"
            $ServersOU = "Servidores_regresiva"
            $Domain = (Get-ADDomain).DistinguishedName
               
            $DCOUPath = "OU=$DCOU,$Domain"
            $ServidorOUPath = "OU=$ServersOU,$Domain" 
            $gpoDCName = "CCN-STIC-570A25_DC_Regresiva"
            $gpoServername = "CCN-STIC-570A25_Servidor Miembro_Regresiva"
            $gpoPath = "C:\Scripts\REGRESION\GPOS"

             if (-not (Get-GPO -Name $gpoDCName -ErrorAction SilentlyContinue)) {
                New-GPO -Name $gpoDCName | Out-Null
                Write-Host "GPO '$gpoDCName' creada."`n`
                } else {
                    Write-Host "GPO '$gpoDCName' ya existe."`n`
                }

                if (-not (Get-GPO -Name $gpoServername -ErrorAction SilentlyContinue)) {
                    New-GPO -Name $gpoServername | Out-Null
                    Write-Host "GPO '$gpoServername' creada."`n`
                } else {
                    Write-Host "GPO '$gpoServername' ya existe."`n`
            }


            Import-GPO -BackupGPOName "$gpoDCName" -TargetName $gpoDCName -Path "$gpoPath" | Out-Null
            Import-GPO -BackupGPOName "$gpoServername" -TargetName $gpoServername -Path "$gpoPath" | Out-Null


            $Domain = (Get-ADDomain).DistinguishedName
            $OUs = @("$DCOU", "$ServersOU")

            Write-Host Comprobando Unidades Organizativas...`n
            foreach ($OU in $OUs)
            {
                Write-Host Comprobando Unidad Organizativa $OU
                $OuName = "OU=$OU,$Domain"
                if (Get-ADOrganizationalUnit -LDAPFilter "(distinguishedName=$OuName)" -ErrorAction SilentlyContinue) 
                {
                    Write-Host la Unidad Organizativa $OU existe
                    Write-Host ADVERTENCIA: Las GPO de regresion se aplican a esta Unidad Organizativa. Si no se aplican filtros, se le aplicará la politica a todos los objetos que contenga.`n -ForegroundColor Yellow
                    Set-GPInheritance -Target "$OuName" -IsBlocked Yes
                    Write-Host ADVERTENCIA: Se ha bloqueado la herencia de la OU $OuName. `n -ForegroundColor Yellow
                    Write-Host Continuando...`n
                }
                else 
                {
                    Write-Host Creando Unidad Organizativa $OU
                    New-ADOrganizationalUnit -Name "$OU" -Path "$domain" 
                    Set-GPInheritance -Target "$OuName" -IsBlocked Yes
                    Write-Host Unidad Organizativa creada...`n
                }
            }


            if (-not ((Get-GPInheritance -Target $DCOUPath).GpoLinks | Where-Object {$_.DisplayName -like $gpoDCName} ))  {
                New-GPLink -Name $gpoDCName -Target $DCOUPath -LinkEnabled no -order 1
                Write-Host "GPO vinculada a $DCOUPath"`n`
            } else {
                Write-Host "GPO ya está vinculada a $DCOUPath"`n`
            }
                if (-not ((Get-GPInheritance -Target $ServidorOUPath).GpoLinks | Where-Object {$_.DisplayName -like $gpoServername} ))  {
                New-GPLink -Name $gpoServername -Target $ServidorOUPath -LinkEnabled no -order 1
                Write-Host "GPO vinculada a $ServidorOUPath"`n`
            } else {
                Write-Host "GPO ya está vinculada a $ServidorOUPath"`n`
            }
        }

        # === COPIA PERMISOS DE CARPETAS Y ARCHIVOS ===

        $permisos = Import-Csv -Path "C:\Scripts\REGRESION\PERMISOS\permisos.csv"

        Add-Content -Path c:\Scripts\REGRESION\PERMISOS\permisos_pre_bastionado.csv -Value "ruta!permisos"
        foreach ($permiso in $permisos)
        {
        
            $ruta = $permiso.ruta
            $rutaExpandida = [Environment]::ExpandEnvironmentVariables($ruta)

            if (Test-Path $rutaExpandida)
            {
            $acl = get-acl -path $rutaExpandida
            Add-Content -Path c:\Scripts\REGRESION\PERMISOS\permisos_pre_bastionado.csv -Value "$ruta!$($acl.GetSecurityDescriptorSddlForm('All'))"
            }

        }     
        

        # === EXPORTE CONFIGURACION DE SERVICIOS ===
        # Tipo de inicio, nombre, y Seguridad

        Write-Host Copiando servicios... `n
        $servicios = Get-Service

        Add-Content -value "name!start_type!SDDL" -Path "C:\Scripts\REGRESION\SERVICIOS\Servicios_Pre_bastionado.csv"
        $i = 0
        $total = $servicios.Count
        foreach ($servicio in $servicios.name) 
        {
 
        $nombre_servicio = & $env:systemroot\system32\sc.exe qc $servicio | Select-String -Pattern "NOMBRE_SERVICIO"
        $tipo_inicio = & $env:systemroot\system32\sc.exe qc $servicio | Select-String -Pattern "TIPO_INICIO"
        $SDDL = & $env:systemroot\system32\sc.exe sdshow $servicio

        $nombre_servicio_format = $nombre_servicio -replace "NOMBRE_SERVICIO: ",''
        $tipo_inicio_format = $tipo_inicio -replace "        TIPO_INICIO        : [0-9]   ",'' 

        Add-Content -value "$nombre_servicio_format!$tipo_inicio_format!$SDDL" -path "C:\Scripts\REGRESION\SERVICIOS\Servicios_Pre_bastionado.csv"

        $i++

        Write-Progress -Activity "Copiando estado actual de los servicios" -Status "$servicio.name" -PercentComplete (($i / $total) * 100)

        }

        Write-Host Servicios copiados correctamente `n
        Write-Progress -Activity "Copiando estado actual de los servicios" -Completed
        pause

    }

# === RESTABLECER COPIA ===
    if ($Accion -eq "IMPORTAR")
    {

        if ( -not (Test-Path C:\Scripts\REGRESION)) 
        {
            Write-Host NO existe una carpeta de regresion en la ruta C:\Scripts\REGRESION, por favor, si desea revertir el bastionado es necesario que esa carpeta exista con los datos guardados durante el exporte del prebastioando.
            Write-Host ADVERTENCIA: No podrá continuar el proceso de reversion si la carpeta no se encuentra con los contenidos necesarios.
            write-Host Saliendo...
            exit
        }

        # === RESTABLECER PERMISOS ===

        Write-Host Restableciendo permisos...
        Write-Host Este proceso puede durar varios minutos.`n
        $permisos = Import-Csv -path "c:\Scripts\REGRESION\PERMISOS\permisos_pre_bastionado.csv" -Delimiter "!"
        Set-MpPreference -DisableRealtimeMonitoring $true
        foreach ($permiso in $permisos) 
        {

        $rutaPermisos = $permiso.ruta
        $carpetapermisos = $permiso.permisos

        $ruta = [Environment]::ExpandEnvironmentVariables($rutaPermisos)

        if (Test-Path $ruta)
        {
            $SDsource = $carpetapermisos
            $SDtarget = get-acl -path $ruta
            $SDtarget.SetSecurityDescriptorSddlForm($SDsource)
            set-acl -Path $ruta -ACLObject $SDtarget
        }
        }
        Set-MpPreference -DisableRealtimeMonitoring $true
        Write-Host Permisos restablecidos `n

    # === RESTABLECER SERVICIOS ===

        Write-Host Restableciendo servicios... `n
        #name!start_type!SDDL

        $i = 0
        $impservicios = Import-csv -path "C:\Scripts\REGRESION\SERVICIOS\Servicios_Pre_bastionado.csv" -Delimiter "!"
        $total = $impservicios.Count
        foreach ($impservicio in $impservicios) 
        {
 
            $nombre_servicio = $impservicio.name
            $tipo_inicio = $impservicio.start_type
            $SDDL = $impservicio.sddl

            if ($tipo_inicio -eq "DEMAND_START"){$servStartType = "demand"}
            elseif($tipo_inicio -eq "AUTO_START"){$servStartType = "auto"}
            elseif($tipo_inicio -eq "AUTO_START  (DELAYED)"){$servStartType = "delayed-auto"}
            elseif($tipo_inicio-eq "DISABLED"){$servStartType = "disabled"}
            else{$servStartType = $null}
 
            & $env:systemroot\system32\sc.exe config $nombre_servicio start=$servStartType >$null 2>$null
            & $env:systemroot\system32\sc.exe sdset $nombre_servicio $SDDL >$null 2>$null
            $i++
            Write-Progress -Activity "Restableciendo servicios" -Status " $nombre_servicio" -PercentComplete (($i / $total) * 100)

        }

        Write-Host Servicios copiados correctamente `n
        Write-Progress -Activity "Restableciendo servicios" -Completed


        # === RESTABLECER CARACTERISTICAS ===

        Write-Host Habilitando caracterisiticas y roles previos...
        Write-Host Este proceso puede durar varios minutos.`n

        if (Test-Path "C:\Scripts\CCN-STIC-570A25_Caracteristicas Deshabilitadas.csv") 
        {
        
            Copy-Item "C:\Scripts\CCN-STIC-570A25_Caracteristicas Deshabilitadas.csv" -Destination "C:\Scripts\REGRESION\CARACTERISTICAS"

            $caracteristicas = Import-csv "C:\Scripts\REGRESION\CARACTERISTICAS\CCN-STIC-570A25_Caracteristicas Deshabilitadas.csv" -Delimiter "!"
            
            foreach ($caracteristica in $Caracteristicas) 
            {

                $nombreCaracteristica = $caracteristica.NombreCaracteristica
                Write-Host "Instalando caracteristica $nombreCaracteristica"`n
                Install-WindowsFeature $nombreCaracteristica
            }

            Write-Host Caracteristicas instaladas...`n

        }

        else {Write-Host No ha sido posible recuperar las caracteristicas porque no se encuentra el archivo C:\Scripts\CCN-STIC-570A25_Caracteristicas Deshabilitadas.csv generado al deshabilitar las caracteristicas.`n}


        # === DESHABILITAR REGISTROS CONEXIONES USB ===
        $eventosusb = Get-WinEvent -ListLog 'Microsoft-Windows-DriverFrameworks-UserMode/Operational'
        $eventosusb.IsEnabled = $false
        $eventosusb.SaveChanges()

        pause
    }


}
else {Write-Host Saliendo...;exit}



}



elseif ((Get-Culture).name -like "*en*"){


# === START AND VARIABLES ===
Clear-Host
$Accion = $null
$RutaScript = "$PSScriptRoot"
$Advertencia = "---WARNING---"
$FinAdvertencia = "---END WARNING---"
$DisclaimerMSG = @'
This script allows you to perform a backup as well as revert certain configurations applied during the hardening process, facilitating the resolution of issues arising from it. To ensure proper use and minimize potential system impacts, it is essential to follow the guidelines established in the corresponding CCN-STIC guide, as well as understand the effects its execution may have on the operating environment.
'@
$anchoConsola = [console]::WindowWidth
$posicion = [Math]::Max(0, ($anchoConsola - $Advertencia.Length) / 2)
$posicion2 = [Math]::Max(0, ($anchoConsola - $FinAdvertencia.Length) / 2)

# === DISCLAIMER ===

Write-Host
Write-Host (' ' * $posicion + $advertencia) -ForegroundColor red
Write-Host $DisclaimerMSG -ForegroundColor Yellow
Write-Host (' ' * $posicion2 + $Finadvertencia) -ForegroundColor red


# === EXPORT/IMPORT MENU ===

$ExportImportConfirmar = [System.Management.Automation.Host.ChoiceDescription[]] @("&EXPORTAR","&IMPORTAR","&SALIR")
$ExportImport = $host.UI.PromptForChoice("Do you want to export the current configuration or import the saved one?", "Select an option:", $ExportImportConfirmar, 2)
if ($ExportImport -eq 0) 
{
    Write-Host Preparing pre-hardening backup...
    $Accion = "EXPORTAR"
}
elseif ($ExportImport -eq 1) 
{
    Write-Host Restoring pre-hardening backup...
    $Accion = "IMPORTAR"
}
elseif ($ExportImport -eq 2) 
{
    Write-Host Exiting...
    exit
}


$ExportImportAsegurarConfirmar = [System.Management.Automation.Host.ChoiceDescription[]] @("&SI","&NO")
$ExportImportAsegurar = $host.UI.PromptForChoice("Are you sure you want to $Action the configuration?", "Select an option:", $ExportImportAsegurarConfirmar, 1)
if ($ExportImportAsegurar -eq 0) 
{
    Write-Host Starting configuration $Accion...
    Write-Host

    if ($Accion -eq "EXPORTAR")
    {



    # === CHECK AND CREATION FOLDER === 

        if (-not (Test-Path C:\Scripts)){
            Write-Host Creating Script folder...`n
            New-item -Path C:\Scripts -ItemType directory | Out-Null
            Write-Host Folder created´n´
        }
       

        if (Test-Path C:\Scripts\REGRESION) 
        {
            Write-Host A regression folder exists at path c:\SCRIPT\REGRESION. Please, if you want to save the system configuration again, you need to either store this folder in a safe location or rename it.
            Write-Host WARNING: You will not be able to continue the export process if the folder is in the current path.
            write-Host Exiting...
            exit
        }
        else 
        {
            Write-Host Copying hardening files... `n
            Copy-Item -Path $RutaScript\REGRESION -Destination c:\Scripts -Recurse
            Write-Host Files copied `n
        }


        # === CREATE OU AND REGRESSIVE GPOS ===


        if ((Get-CimInstance Win32_OperatingSystem).caption -like "*202*" -and (Get-CimInstance Win32_ComputerSystem).DomainRole -eq 5)

        {

            $DCOU = "Domain Controllers_regresiva"
            $ServersOU = "Servidores_regresiva"
            $Domain = (Get-ADDomain).DistinguishedName
               
            $DCOUPath = "OU=$DCOU,$Domain"
            $ServidorOUPath = "OU=$ServersOU,$Domain" 
            $gpoDCName = "CCN-STIC-570A25_DC_Regresiva"
            $gpoServername = "CCN-STIC-570A25_Servidor Miembro_Regresiva"
            $gpoPath = "C:\Scripts\REGRESION\GPOS"

             if (-not (Get-GPO -Name $gpoDCName -ErrorAction SilentlyContinue)) {
                New-GPO -Name $gpoDCName | Out-Null
                Write-Host "GPO '$gpoDCName' created."`n`
                } else {
                    Write-Host "GPO '$gpoDCName' exists."`n`
                }

                if (-not (Get-GPO -Name $gpoServername -ErrorAction SilentlyContinue)) {
                    New-GPO -Name $gpoServername | Out-Null
                    Write-Host "GPO '$gpoServername' created."`n`
                } else {
                    Write-Host "GPO '$gpoServername' exists."`n`
            }


            Import-GPO -BackupGPOName "$gpoDCName" -TargetName $gpoDCName -Path "$gpoPath" | Out-Null
            Import-GPO -BackupGPOName "$gpoServername" -TargetName $gpoServername -Path "$gpoPath" | Out-Null


            $Domain = (Get-ADDomain).DistinguishedName
            $OUs = @("$DCOU", "$ServersOU")

            Write-Host Checking Organizational Units...`n
            foreach ($OU in $OUs)
            {
                Write-Host Checking $OU Organizational Unit
                $OuName = "OU=$OU,$Domain"
                if (Get-ADOrganizationalUnit -LDAPFilter "(distinguishedName=$OuName)" -ErrorAction SilentlyContinue) 
                {
                    Write-Host $OU Organizational unit exist
                    Write-Host WARNING: The regression GPOs are applied to this Organizational Unit. If no filters are applied, the policy will be applied to all objects it contains.`n -ForegroundColor Yellow
                    Set-GPInheritance -Target "$OuName" -IsBlocked Yes
                    Write-Host WARNING: Inheritance for the $OuName OU has been blocked. `n -ForegroundColor Yellow
                    Write-Host Continuing...`n
                }
                else 
                {
                    Write-Host Creating $OU organizational Unit.
                    New-ADOrganizationalUnit -Name "$OU" -Path "$domain" 
                    Set-GPInheritance -Target "$OuName" -IsBlocked Yes
                    Write-Host Organizational Unit created...`n
                }
            }


            if (-not ((Get-GPInheritance -Target $DCOUPath).GpoLinks | Where-Object {$_.DisplayName -like $gpoDCName} ))  {
                New-GPLink -Name $gpoDCName -Target $DCOUPath -LinkEnabled no -order 1
                Write-Host "GPO linked to $DCOUPath"`n`
            } else {
                Write-Host "GPO is alredy linked to $DCOUPath"`n`
            }
                if (-not ((Get-GPInheritance -Target $ServidorOUPath).GpoLinks | Where-Object {$_.DisplayName -like $gpoServername} ))  {
                New-GPLink -Name $gpoServername -Target $ServidorOUPath -LinkEnabled no -order 1
                Write-Host "GPO linked to $ServidorOUPath"`n`
            } else {
                Write-Host "GPO is alredy linked to $ServidorOUPath"`n`
            }
        }

        # === COPY FOLDER AND FILE PERMISSIONS ===

        $permisos = Import-Csv -Path "C:\Scripts\REGRESION\PERMISOS\permisos.csv"

        Add-Content -Path c:\Scripts\REGRESION\PERMISOS\permisos_pre_bastionado.csv -Value "ruta!permisos"
        foreach ($permiso in $permisos)
        {
        
            $ruta = $permiso.ruta
            $rutaExpandida = [Environment]::ExpandEnvironmentVariables($ruta)

            if (Test-Path $rutaExpandida)
            {
            $acl = get-acl -path $rutaExpandida
            Add-Content -Path c:\Scripts\REGRESION\PERMISOS\permisos_pre_bastionado.csv -Value "$ruta!$($acl.GetSecurityDescriptorSddlForm('All'))"
            }

        }     
        

        # === EXPORT SERVICE CONFIGURATION ===
        # Tipo de inicio, nombre, y Seguridad

        Write-Host Copying services... `n
        $servicios = Get-Service

        Add-Content -value "name!start_type!SDDL" -Path "C:\Scripts\REGRESION\SERVICIOS\Servicios_Pre_bastionado.csv"
        $i = 0
        $total = $servicios.Count
        foreach ($servicio in $servicios.name) 
        {
 
        $nombre_servicio = & $env:systemroot\system32\sc.exe qc $servicio | Select-String -Pattern "SERVICE_NAME"
        $tipo_inicio = & $env:systemroot\system32\sc.exe qc $servicio | Select-String -Pattern "START_TYPE"
        $SDDL = & $env:systemroot\system32\sc.exe sdshow $servicio

        $nombre_servicio_format = $nombre_servicio -replace "SERVICE_NAME: ",''
        $tipo_inicio_format = $tipo_inicio -replace "        START_TYPE         : [0-9]   ",'' 

        Add-Content -value "$nombre_servicio_format!$tipo_inicio_format!$SDDL" -path "C:\Scripts\REGRESION\SERVICIOS\Servicios_Pre_bastionado.csv"

        $i++

        Write-Progress -Activity "Copying current state of the services" -Status "$servicio.name" -PercentComplete (($i / $total) * 100)

        }

        Write-Host Services copied successfully `n
        Write-Progress -Activity "Copying current state of the services" -Completed
        pause

    }

# === RESTORE BACKUP ===
    if ($Accion -eq "IMPORTAR")
    {

        if ( -not (Test-Path C:\Scripts\REGRESION)) 
        {
            Write-Host There is NO regression folder at path C:\Script\REGRESION. Please note, if you want to revert the hardening, this folder must exist with the data saved during the pre-hardening export.
            Write-Host WARNING: You will not be able to continue the reversal process if the folder does not contain the necessary contents.
            write-Host Exiting...
            exit
        }

        # === RESTORE PERMISSIONS ===

        Write-Host Restoring permissions...
        Write-Host This process may take several minutes.`n
        $permisos = Import-Csv -path "c:\Scripts\REGRESION\PERMISOS\permisos_pre_bastionado.csv" -Delimiter "!"
        Set-MpPreference -DisableRealtimeMonitoring $true
        foreach ($permiso in $permisos) 
        {

        $rutaPermisos = $permiso.ruta
        $carpetapermisos = $permiso.permisos

        $ruta = [Environment]::ExpandEnvironmentVariables($rutaPermisos)

        if (Test-Path $ruta)
        {
            $SDsource = $carpetapermisos
            $SDtarget = get-acl -path $ruta
            $SDtarget.SetSecurityDescriptorSddlForm($SDsource)
            set-acl -Path $ruta -ACLObject $SDtarget
        }
        }
        Set-MpPreference -DisableRealtimeMonitoring $true
        Write-Host Permissions restored `n

    # === RESTORE SERVICES ===

        Write-Host Restoring services... `n
        #name!start_type!SDDL

        $i = 0
        $impservicios = Import-csv -path "C:\Scripts\REGRESION\SERVICIOS\Servicios_Pre_bastionado.csv" -Delimiter "!"
        $total = $impservicios.Count
        foreach ($impservicio in $impservicios) 
        {
 
            $nombre_servicio = $impservicio.name
            $tipo_inicio = $impservicio.start_type
            $SDDL = $impservicio.sddl

            if ($tipo_inicio -eq "DEMAND_START"){$servStartType = "demand"}
            elseif($tipo_inicio -eq "AUTO_START"){$servStartType = "auto"}
            elseif($tipo_inicio -eq "AUTO_START  (DELAYED)"){$servStartType = "delayed-auto"}
            elseif($tipo_inicio-eq "DISABLED"){$servStartType = "disabled"}
            else{$servStartType = $null}
 
            & $env:systemroot\system32\sc.exe config $nombre_servicio start=$servStartType >$null 2>$null
            & $env:systemroot\system32\sc.exe sdset $nombre_servicio $SDDL >$null 2>$null
            $i++
            Write-Progress -Activity "Restoring services" -Status " $nombre_servicio" -PercentComplete (($i / $total) * 100)

        }

        Write-Host Services restored `n
        Write-Progress -Activity "Restoring services" -Completed


        # === RESTORE FEATURES ===

        Write-Host Enabling previous features and roles...
        Write-Host This process may take several minutes.`n

        if (Test-Path "C:\Scripts\CCN-STIC-570A25_Caracteristicas Deshabilitadas.csv") 
        {
        
            Copy-Item "C:\Scripts\CCN-STIC-570A25_Caracteristicas Deshabilitadas.csv" -Destination "C:\Scripts\REGRESION\CARACTERISTICAS"

            $caracteristicas = Import-csv "C:\Scripts\REGRESION\CARACTERISTICAS\CCN-STIC-570A25_Caracteristicas Deshabilitadas.csv" -Delimiter "!"
            
            foreach ($caracteristica in $Caracteristicas) 
            {

                $nombreCaracteristica = $caracteristica.NombreCaracteristica
                Write-Host "Installing $nombreCaracteristica feature"`n
                Install-WindowsFeature $nombreCaracteristica
            }

            Write-Host Features installed...`n

        }

        else {Write-Host It has not been possible to recover the features because the C:\Scripts\CCN-STIC-570A25_Caracteristicas Deshabilitadas.csv file generated when disabling the features cannot be found.`n}


        # === DISABLE USB CONNECTION LOGS ===
        $eventosusb = Get-WinEvent -ListLog 'Microsoft-Windows-DriverFrameworks-UserMode/Operational'
        $eventosusb.IsEnabled = $false
        $eventosusb.SaveChanges()

        pause
    }


}
else {Write-Host Saliendo...;exit}





}


else {Write-Host El sistema debe estar en ingles o en español}
