@echo off
cls
@echo -----------------------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Configuracion completa FS (Materias Clasificadas)
@echo -----------------------------------------------------------------------------------------------
@echo.
@echo  Este script ejecuta todas las configuraciones de seguridad realizadas durante la guia CCN-STIC-573,
@echo  que se ejecutan a traves de scripts, y que se realizan sobre los equipos de tipo Servidor Miembro
@echo  que cumplen el rol de Servidor de Ficheros bajo el perfilado Materias Clasificadas. 
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros y scripts se encuentran en el 
@echo  directorio "C:\Scripts".
@echo.
@echo  Nota: Este scripts no realiza los pasos que necesitan de acciones manuales durante la guia
@echo  CCN-STIC-573. Revise el documento para asegurar que ha ejecutado todas las acciones necesarias
@echo  de configuracion.
@echo.
@echo -----------------------------------------------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Deshabilitar_Autenticacion_compartida.ps1
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Habilitar_Enumeracion_Basada_en_Acceso_ABE.ps1
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Habilitar_registro_acciones_File_Server.ps1
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Habilitar_Cifrado_de_acceso_a_datos_y_cifrado_red.ps1
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Definir_auditoria_en_recursos_compartidos.ps1
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Habilitar_Auditoria_de_filtros.ps1
@REM powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Desinstala_roles_y_caracteristicas_servidor_FS.ps1
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Deshabilitar_Informacion_y_asistencia_acceso_denegado.ps1
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Copia_seguridad_configuraciones_FS.ps1
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Configuracion_LeasingMode_y_NameHardeningLevel.ps1
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Comprobacion_instalacion_roles_DFS_NFS_BC_(UO-MC).ps1
@echo off

@echo ----------------------------------------------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Configuracion completa FS (Materias Clasificadas) : EJECUCION FINALIZADA
@echo ----------------------------------------------------------------------------------------------------------------------
pause
cls
