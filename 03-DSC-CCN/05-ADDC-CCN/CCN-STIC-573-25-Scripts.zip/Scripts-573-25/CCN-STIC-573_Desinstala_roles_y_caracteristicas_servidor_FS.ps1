Clear-Host

#Conjunto de roles y caracter�sticas necesarias que van a mantenerse tras la ejecuci�n del script
$mantener_rol_servidor = @(

)

#Conjunto de roles y caracter�sticas que se mantienen por defecto
$mantener_rol = @(
    "FileAndStorage-Services",#por defecto
	"Storage-Services",#por defecto
    "AD-Domain-Services",#nuevo
    "DNS",#nuevo       
    "NET-Framework-45-Features",#por defecto
    "NET-Framework-45-Core",#por defecto
    "NET-WCF-Services45",#por defecto, no contemplado en script antiguo
    "NET-WCF-TCP-PortSharing45",#por defecto, no contemplado en script antiguo
    "GPMC",#nuevo ADDS
    "Windows-Defender",#por defecto, no contemplado en script antiguo
    "System-DataArchiver",#por defecto, no contemplado en script antiguo
    "BitLocker",#nuevo BL
    "WoW64-Support",#por defecto
    "Windows-Server-Backup",#nuevo Backup
    "EnhancedStorage",#nuevo BL
    "RSAT-Feature-Tools",#nuevo BL
    "RSAT-Feature-Tools-BitLocker",#nuevo BL
    "RSAT-Feature-Tools-BitLocker-RemoteAdminTool",#nuevo BL
    "RSAT-Feature-Tools-BitLocker-BdeAducExt",#nuevo BL
    "RSAT-AD-Tools",#nuevo ADDS
    "RSAT-ADDS",#nuevo ADDS
    "RSAT-AD-AdminCenter",#nuevo ADDS
    "RSAT-ADDS-Tools",#nuevo ADDS
    "RSAT-AD-PowerShell",#nuevo ADDS
    "RSAT-DNS-Server",#nuevo ADDS
    "PowerShellRoot",#por defecto
    "PowerShell",#por defecto
    "PowerShell-ISE",#no instalado por defecto
    "User-Interfaces-Infra",#no instalado por defecto
    "Server-Gui-Mgmt-Infra",#no instalado por defecto
    "Server-Gui-Shell",#no instalado por defecto
    "FS-SMB1"#no instalado por defecto
#Nuevos para mantener seg�n roles instalados del apartado "Servicios de archivos y almacenamiento/Servicios de iSCSI y archivo"
	"File-Services",#File Server
    "FS-FileServer",#File Server
	"FS-Resource-Manager",#Administrador de recursos
	"RSAT",#Administrador de recursos
	"RSAT-Role-Tools",#Administrador de recursos
	"RSAT-File-Services",#Administrador de recursos
	"RSAT-FSRM-Mgmt",#Administrador de recursos
	"FS-BranchCache",#BranchCache
	"FS-SyncShareService",#Carpetas de trabajo
	"Web-WHC",#Carpetas de trabajo
	"FS-Data-Deduplication",#Desduplicaci�n de datos
	"FS-DFS-Namespace",#DFS
	"RSAT-DFS-Mgmt-Con",#DFS
	"iSCSITarget-VSS-VDS",#iSCSI
	"FS-DFS-Replication",#Replicaci�n DFS
	"FS-VSS-Agent",#VSS
	"FS-iSCSITarget-Server",#Destino iSCSI
	"FS-NFS-Service",#NFS
	"RSAT-NFS-Admin",#NFS
#Nuevos para mantener seg�n caracter�sticas del apartado BranchCache
	"BranchCache"#BranchCache
)

#Se importa el modulo de Server Manager para poder hacer uso de sus comandos
Import-Module ServerManager

#Creaci�n de variable para alojar las caracter�sticas a desinstalar y variables de control
$habilitadas = @()
$fechafichero = Get-Date -Format "yyyy-MM-dd"
$horafichero = Get-Date -Format "HH.mm"
Set-Content -Value "" C:\Scripts\CCN-STIC-573A23_Roles_y_caracteristicas_deshabilitadas_$fechafichero`_$horafichero.txt
$ficherofeatures = "C:\Scripts\CCN-STIC-573A23_Roles_y_caracteristicas_deshabilitadas_$fechafichero`_$horafichero.txt"
Clear-Content $ficherofeatures

#Lista los roles y caracteristicas instalados
Write-Host "--------------------------------------------"
Write-Host �Lista de roles y caracteristicas instalados:"
Write-Host "--------------------------------------------"
$habilitadas = Get-WindowsFeature | where-object {$_.Installed} | select-object displayname,name,featuretype | sort DisplayName
$habilitadas | Out-Default
Write-Host "Fin de la lista."

#Espera a que se pulse una tecla para continuar
Write-Host "A continuaci�n se desinstalar�n todos los roles y caracter�sticas que no sean necesarios"
Write-Host "en un equipo de tipo Servidor Miembro o que hayan sido determinados en el presente script."
Write-Host "Nota: Si desea cancelar el proceso pulse 'Ctrl+C'" -ForegroundColor DarkYellow
pause

#Deshabilita todos los roles y caracteristicas instalados salvo los necesarios
foreach ($i in $habilitadas ) {
	#No se deshabilitan las caracteristicas definidas en el array
	if ($mantener_rol -notcontains $i.Name -and $mantener_rol_servidor -notcontains $i.Name)	{
        Clear-Host
		Write-Host "Deshabilitando caracteristica: "$i.DisplayName""
		Uninstall-WindowsFeature -Name $i.Name
        $i.Name + ";" + $i.DisplayName + ";" + $i.FeatureType| Add-Content $ficherofeatures
	}
}

Write-Host " "
Write-Host "Puede consultar un registro de las caracter�sticas y/o roles desintalados en el fichero codificado como:" -NoNewline
Write-Host " CCN-STIC-573A23_Roles_y_caracteristicas_deshabilitadas_YYYY-MM-DD_HH.MM.txt" -NoNewline -ForegroundColor Green
Write-Host " ubicado en" -NoNewline
Write-Host " C:\Scripts" -NoNewline -ForegroundColor Green
Write-Host " "
pause

shutdown /r /t 30 /c "El sistema se reiniciara en 30 segundos."