﻿#Creación de variables de control
$fechafichero = Get-Date -Format "yyyy-MM-dd"
$horafichero = Get-Date -Format "HH.mm"

Set-Content -Value "" C:\Scripts\CCN-STIC-573A23_NFSServerConfiguration_$fechafichero`_$horafichero.txt
$ficheroserverconfiguration = "C:\Scripts\CCN-STIC-573A23_NFSServerConfiguration_$fechafichero`_$horafichero.txt"
Clear-Content $ficheroserverconfiguration

Set-Content -Value "" C:\Scripts\CCN-STIC-573A23_NFSShare_$fechafichero`_$horafichero.txt
$ficheronfsshare = "C:\Scripts\CCN-STIC-573A23_NFSShare_$fechafichero`_$horafichero.txt"
Clear-Content $ficheronfsshare

#Obtener un fichero de configuraciones del servidor de ficheros para el rol NFS, tanto de su lado servidor como de los recursos compartidos
Write-Host "Obteniendo configuración de seguridad aplicada en el Servidor de Ficheros para NFS..."
Get-NfsServerConfiguration | Select-Object * | Out-File $ficheroserverconfiguration
Write-Host " "
Write-Host "Puede consultar un registro de las configuraciones obtenidas del lado servidor en el fichero codificado como:" -NoNewline
Write-Host " CCN-STIC-573A23_NFSServerConfiguration_YYYY-MM-DD_HH.MM.txt" -NoNewline -ForegroundColor Green
Write-Host " ubicado en" -NoNewline
Write-Host " C:\Scripts" -NoNewline -ForegroundColor Green
Write-Host " "

Write-Host "Obteniendo configuración de los recursos compartidos..."
Get-NfsShare | Select-Object * | Out-File $ficheronfsshare
Write-Host " "
Write-Host "Puede consultar un registro de los parámetro de los recursos compartidos en el fichero codificado como:" -NoNewline
Write-Host " CCN-STIC-573A23_NFSShare_YYYY-MM-DD_HH.MM.txt" -NoNewline -ForegroundColor Green
Write-Host " ubicado en" -NoNewline
Write-Host " C:\Scripts" -NoNewline -ForegroundColor Green
Write-Host " "