﻿#Impedir el almacenamiento en caché de la información de los recursos compartidos
Write-Host "Impidiendo el almacenamiento en caché de la información de los recursos compartidos..."
$shares = (Get-SmbShare | Where-Object -Property Name -NotLike *$).Name
foreach ($i in $shares) {
    Set-SmbShare -Name $i -CachingMode None -Confirm:$false
}