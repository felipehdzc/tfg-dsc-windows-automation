﻿Write-Host "Estableciendo la configuración de seguridad para el servidor NFS:"
Write-Host "  - Impedir que se creen directorios ocultos por medio del uso de caracteres especiales."
Write-Host "  - Habilitar y definir el tiempo de renovación para la autenticación en el servidor."
Write-Host "  - Limitar el acceso a recursos compartidos por ID."
Write-Host "  - Impedir el acceso anónimo a los recurso compartidos por NFS."
Write-Host "  - Limitar el acceso al usuario 'root' de Linux."

#Deshabilitar que los directorios que inicien con el carácter punto (".") al crearse lo hagan como directorios ocultos
Set-NfsServerConfiguration -HideFilesBeginningInDot 0 -Confirm:$false

#Habilitar y definir el periodo de tiempo para la renovación de la autenticación
Set-NfsServerConfiguration -EnableAuthenticationRenewal 1 -Confirm:$false
Set-NfsServerConfiguration -AuthenticationRenewalIntervalSec 600 -Confirm:$false

#Especifica la cuenta de Windows que utiliza un servidor NFS para representar permisos de tipo World/Other en los archivos cuando se utiliza la entidad de seguridad AUTH_UNIX
#Set-NfsServerConfiguration -WorldAccount "Authenticated Users"

#Abrir archivos y directorios por nombre, en lugar de abrirlos por ID de archivo
Set-NfsServerConfiguration -AlwaysOpenByName 1 -Confirm:$false

#Obtener todos los recursos NFS compartidos y modificar la configuración para inhabilitar el acceso anónimo y la posibilidad de hacer uso del usuario root
$shares = (Get-NfsShare | Where-Object -Property Name -NotLike *$).Name
foreach ($i in $shares) {
    Set-NfsShare -Name $i -EnableAnonymousAccess 0 -Confirm:$false
	Set-NfsShare -Name $i -AllowRootAccess 0 -Confirm:$false
}

#Necesario para que se pueda montar el recurso NFS en Linux independiente (no unido a dominio)
$shares = (Get-NfsShare | Where-Object -Property Name -NotLike *$).Name
foreach ($i in $shares) {
	Set-NfsShare -Name $i -EnableUnmappedAccess 1 -Confirm:$false
}

#Reinicio del servicio de NFS para aplicar los cambios
Write-Host "Reiniciando el servicio NFS para aplicar los cambios..."
Restart-Service -Name NfsService | Out-Null