﻿#Habilitar el cifrado de acceso a datos para todos los recursos compartidos pero permite modificar la opción
<#
Write-Host "Habilitando el cifrado de acceso a datos para todos los recursos compartidos..."
$shares = (Get-SmbShare | Where-Object -Property Name -NotLike *$).Name
foreach ($i in $shares) {
    Set-SmbShare -Name $i -EncryptData $True -Confirm:$false
}
#>
#Habilitar el cifrado de acceso a datos en todo el servidor. Impide que por recurso compartido esto se pueda habilitar o deshabilitar
Write-Host "Habilitando el cifrado de acceso a datos para todos los recursos compartidos..."
Set-SmbServerConfiguration –EncryptData $True -Confirm:$False

#Habilitar la necesidad de cifrado a nivel de red para acceso a los recursos compartidos del servidor de ficheros
Write-Host "Habilitando cifrado a nivel de red..."
Set-SmbServerConfiguration –RejectUnencryptedAccess $true -Confirm:$false