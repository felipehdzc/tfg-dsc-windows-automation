﻿#Importar el módulo de file server
Import-Module FileServerResourceManager

#Deshabilitar el la información de asistencia de acceso denegado
Write-Host "Deshabilitando información de asistencia frente a acceso denegado..."
Set-FsrmAdrSetting -Event AccessDenied -Enabled:$False
Set-FsrmAdrSetting -Event FileNotFound -Enabled:$False

#Deshabilitar la posibilidad de que los usuarios soliciten asistencia vía correo electrónico
Write-Host "Imposibilitando la solicitud de asistencia..."
Set-FsrmAdrSetting -Event AccessDenied -AllowRequests:$False
Set-FsrmAdrSetting -Event FileNotFound -AllowRequests:$False