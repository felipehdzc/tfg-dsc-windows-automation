@echo off
cls
@echo -------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Copia de seguridad FS
@echo -------------------------------------------------------------------
@echo.
@echo  Este script realiza una copia de seguridad de las configuraciones
@echo  definidas en el equipo configurado bajo el rol Servidor de Ficheros
@echo  con el objetivo de poder concer el estado anterior de forma que sea  
@echo  posible reconstruirlo en parte o en su totalidad tras un incidente.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros y
@echo  scripts se encuentran en el directorio "C:\Scripts".
@echo.
@echo -------------------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Copia_seguridad_configuraciones_FS.ps1
@echo off

@echo ------------------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Copia de seguridad FS : EJECUCION FINALIZADA
@echo ------------------------------------------------------------------------------------------
pause
cls
