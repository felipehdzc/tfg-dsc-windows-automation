﻿#Habilitar la posibilidad de establecer el modo de arrendamiento de los recursos compartidos
write-Host "Estableciendo la configuración en el servidor para permitir los modos de arrendamiento de recursos compartidos..."
Set-SmbServerConfiguration -EnableLeasing 1 -Confirm:$false

#Habilitar el modo de arrendamiento en completo (Full) para todos los recursos compartidos de modo que utilice los comportamientos de arrendamiento y bloqueo predeterminados de SMB3
Write-Host "Configurando los recursos compartidos para que utilicen los comportamientos de arrendamiento y bloqueo predeterminados de SMB3..."
$shares = (Get-SmbShare | Where-Object -Property Name -NotLike *$).Name
foreach ($i in $shares) {
    Set-SmbShare -Name $i -LeasingMode Full -Confirm:$false
}

#Configurar el nivel de protección del nombre del servicio SMB
Write-Host "Configurando el nivel de protección del nombre del servicio SMB..."
Set-SmbServerConfiguration -SmbServerNameHardeningLevel 2 -Confirm:$false