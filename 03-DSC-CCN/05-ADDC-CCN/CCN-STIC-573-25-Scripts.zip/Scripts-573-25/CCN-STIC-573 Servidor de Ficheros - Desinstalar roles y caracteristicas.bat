@echo off
cls
@echo ---------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Roles y caracteristicas
@echo ---------------------------------------------------------------------
@echo.
@echo  Este script desinstala del servidor todos los roles y caracteristicas
@echo  que este tenga instalados y no sean necesarios, teniendo en consideracion
@echo  las necesidades de la organizacion.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros y scripts
@echo  se encuentran en el directorio "C:\Scripts".
@echo.
@echo ---------------------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Desinstala_roles_y_caracteristicas_servidor_FS.ps1
@echo off

@echo --------------------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Roles y caracteristicas : EJECUCION FINALIZADA 
@echo --------------------------------------------------------------------------------------------
pause
cls
