﻿#Importar el módulo de file server
Import-Module FileServerResourceManager

#Habilitar la auditoría de filtros
Write-Host "Habilitando la auditoría de filtros..."
Set-FsrmSetting -ReportFileScreenAuditEnable:$True