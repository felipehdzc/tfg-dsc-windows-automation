@echo off
cls
@echo ---------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - BranchCache
@echo ---------------------------------------------------------
@echo.
@echo  Este script impide la posibilidad de que los recursos compartidos
@echo  alojen informacion en cache y esta se encuentre disponible para
@echo  los usuarios cuando estos se encuentran sin conexion.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros
@echo  y scripts se encuentran en el directorio "C:\Scripts".
@echo.
@echo ---------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Configurar_BranchCache_para_archivos_de_red.ps1
@echo off

@echo --------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - BranchCache : EJECUCION FINALIZADA
@echo --------------------------------------------------------------------------------
pause
cls
