﻿#Habilitar el registro de eventos sobre acciones realizadas en el Server Manager dentro del apartado para el Rol de File Server
Write-Host "Habilitando registros de auditoría para las acciones realizadas en los servicios de recursos compartidos dentro del Administrador del Servidor..."
$eventosfs1 = Get-WinEvent -ListLog 'Microsoft-Windows-FileServices-ServerManager-EventProvider/Operational'
$eventosfs1.IsEnabled = $true
$eventosfs1.SaveChanges()

$eventosfs2 = Get-WinEvent -ListLog 'Microsoft-Windows-FileServices-ServerManager-EventProvider/Admin'
$eventosfs2.IsEnabled = $true
$eventosfs2.SaveChanges()

#Habilitar el registro para eventos relacionados con NTFS como elemento requerido en la compartición de ficheros
Write-Host "Habilitando registros de auditoría para eventos del sistema de archivos NTFS..."
$eventosfs3 = Get-WinEvent -ListLog 'Microsoft-Windows-Ntfs/WHC'
$eventosfs3.IsEnabled = $true
$eventosfs3.SaveChanges()

$eventosfs4 = Get-WinEvent -ListLog 'Microsoft-Windows-Ntfs/Operational'
$eventosfs4.IsEnabled = $true
$eventosfs4.SaveChanges()

#Habilitar registro de accesos SMBv1
Write-Host "Habilitando auditoría para SMBv1..."
Set-SmbServerConfiguration -AuditSmb1Access $true -Confirm:$false