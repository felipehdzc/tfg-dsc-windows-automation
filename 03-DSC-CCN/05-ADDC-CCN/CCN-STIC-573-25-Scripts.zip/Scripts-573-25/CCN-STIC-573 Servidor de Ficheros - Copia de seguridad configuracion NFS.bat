@echo off
cls
@echo --------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Copia de seguridad NFS
@echo --------------------------------------------------------------------
@echo.
@echo  Este script realiza una copia de seguridad de las configuraciones
@echo  definidas en el equipo configurado bajo el rol Servidor de Ficheros
@echo  con el objetivo de poder concer el estado anterior de forma que sea 
@echo  posible reconstruirlo en parte o en su totalidad tras un incidente.
@echo.
@echo  Concretamente se va a realizar la copia de seguridad de las configuraciones
@echo  definidas para el rol NFS.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros
@echo  y scripts se encuentran en el directorio "C:\Scripts".
@echo.
@echo --------------------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Copia_seguridad_configuraciones_NFS.ps1
@echo off

@echo -------------------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Copia de seguridad NFS : EJECUCION FINALIZADA
@echo -------------------------------------------------------------------------------------------
pause
cls
