﻿#Habilitar auditoría del servidor NFS
Write-Host "Habilitando la auditoría del servidor NFS..."
Set-NfsServerConfiguration -LogActivity all

$eventosnfs1 = Get-WinEvent -ListLog 'Microsoft-Windows-ServicesForNFS-Server/Operational'
$eventosnfs1.IsEnabled = $true
$eventosnfs1.SaveChanges()

$eventosnfs2 = Get-WinEvent -ListLog 'Microsoft-Windows-ServicesForNFS-Server/Notifications'
$eventosnfs2.IsEnabled = $true
$eventosnfs2.SaveChanges()

$eventosnfs3 = Get-WinEvent -ListLog 'Microsoft-Windows-ServicesForNFS-Server/IdentityMapping'
$eventosnfs3.IsEnabled = $true
$eventosnfs3.SaveChanges()

$eventosnfs4 = Get-WinEvent -ListLog 'Microsoft-Windows-ServicesForNFS-Server/Admin'
$eventosnfs4.IsEnabled = $true
$eventosnfs4.SaveChanges()

$eventosnfs5 = Get-WinEvent -ListLog 'Microsoft-Windows-ServicesForNFS-Portmapper/Admin'
$eventosnfs5.IsEnabled = $true
$eventosnfs5.SaveChanges()

#Reinicio del servicio de NFS para aplicar los cambios
Write-Host "Reiniciando el servicio NFS para aplicar los cambios..."
Restart-Service -Name NfsService