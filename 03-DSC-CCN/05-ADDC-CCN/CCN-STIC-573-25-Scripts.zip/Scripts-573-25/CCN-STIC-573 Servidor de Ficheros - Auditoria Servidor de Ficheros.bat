@echo off
cls
@echo ----------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Auditoria Servidor de Ficheros
@echo ----------------------------------------------------------------------------
@echo.
@echo  Este script tiene como objetivo realizar las configuraciones necesarias para
@echo  habilitar la auditoria sobre las acciones que se realizar sobre el rol de
@echo  Servidor de Ficheros dentro del Administrador del Servidor, la auditoria sobre
@echo  acciones del sistema de archivos NTFS y la auditoria sobre SMB.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros y scripts se
@echo  encuentran en el directorio "C:\Scripts".
@echo.
@echo ----------------------------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Habilitar_registro_acciones_File_Server.ps1
@echo off

@echo ---------------------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Auditoria Server Manager : EJECUCION FINALIZADA 
@echo ---------------------------------------------------------------------------------------------
pause
cls
