@echo off
cls
@echo ----------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Servidor NFS
@echo ----------------------------------------------------------
@echo.
@echo  Este script tiene como objetivo establecer las configuraciones
@echo  de seguridad necesarias para un equipo bajo el rol de Servidor
@echo  de Ficheros que utiliza el rol de Servidor NFS para compartir
@echo  archivos.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros
@echo  y scripts se encuentran en el directorio "C:\Scripts".
@echo.
@echo ----------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Configurar_Servidor_NFS.ps1
@echo off

@echo ---------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Servidor NFS : EJECUCION FINALIZADA 
@echo ---------------------------------------------------------------------------------
pause
cls
