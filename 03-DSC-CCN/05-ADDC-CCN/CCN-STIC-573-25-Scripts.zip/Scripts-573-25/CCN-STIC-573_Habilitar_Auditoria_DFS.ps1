﻿#Habilitar el registro de eventos para DFS como uno de los posibles roles de compartición de ficheros
Write-Host "Habilitando registros de auditoría para DFS..."
$eventosfs5 = Get-WinEvent -ListLog 'Microsoft-Windows-DFSN-Server/Operational'
$eventosfs5.IsEnabled = $true
$eventosfs5.SaveChanges()

$eventosfs6 = Get-WinEvent -ListLog 'Microsoft-Windows-DFSN-Server/Admin'
$eventosfs6.IsEnabled = $true
$eventosfs6.SaveChanges()