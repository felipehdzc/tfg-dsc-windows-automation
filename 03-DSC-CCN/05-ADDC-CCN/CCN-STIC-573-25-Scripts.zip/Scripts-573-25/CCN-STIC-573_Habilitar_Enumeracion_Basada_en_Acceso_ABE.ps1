﻿#Habilitar la enumeración basada en acceso para todos los recursos compartidos
Write-Host "Habilitando la Enumeración Basada en el Acceso para todos los recursos compartidos..."
$shares = (Get-SmbShare | Where-Object -Property Name -NotLike *$).Name
foreach ($i in $shares) {
    Set-SmbShare -Name $i -FolderEnumerationMode AccessBased -Confirm:$false
}