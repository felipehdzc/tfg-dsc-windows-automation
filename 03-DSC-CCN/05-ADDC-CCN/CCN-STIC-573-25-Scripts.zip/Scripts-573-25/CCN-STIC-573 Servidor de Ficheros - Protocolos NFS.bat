@echo off
cls
@echo ------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Protocolos NFS
@echo ------------------------------------------------------------
@echo.
@echo  Este script tiene como objetivo configurar los procolos adecuados
@echo  para NFS durante la comparticion de archivos del servidor NFS.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros
@echo  y scripts se encuentran en el directorio "C:\Scripts".
@echo.
@echo ------------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Configurar_Servidor_NFS_protocolos.ps1
@echo off

@echo -----------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Protocolos NFS : EJECUCION FINALIZADA
@echo -----------------------------------------------------------------------------------
pause
cls
