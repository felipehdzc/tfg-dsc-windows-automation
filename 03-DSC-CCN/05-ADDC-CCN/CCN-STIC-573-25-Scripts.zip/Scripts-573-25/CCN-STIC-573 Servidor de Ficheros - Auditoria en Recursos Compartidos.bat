@echo off
cls
@echo ---------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Auditoria Recurso compartidos
@echo ---------------------------------------------------------------------------
@echo.
@echo  Este script tiene como objetivo establecer una auditoria en los recursos
@echo  compartidos de los que dispone el Servidor de Ficheros. El script no tiene
@echo  la finalidad de sustituir la auditoria ya establecida en dichos recursos,
@echo  si no asegurar que se establece una auditoria para todos ellos en caso de
@echo  no disponer de la misma.
@echo.
@echo  Puede adaptar las configuraciones de este script si asi lo necesita para
@echo  que se ajuste a las necesidades de su organizacion.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros y scripts
@echo  se encuentran en el directorio "C:\Scripts".
@echo.
@echo ---------------------------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Definir_auditoria_en_recursos_compartidos.ps1
@echo off

@echo --------------------------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Auditoria Recurso compartidos : EJECUCION FINALIZADA
@echo --------------------------------------------------------------------------------------------------
pause
cls
