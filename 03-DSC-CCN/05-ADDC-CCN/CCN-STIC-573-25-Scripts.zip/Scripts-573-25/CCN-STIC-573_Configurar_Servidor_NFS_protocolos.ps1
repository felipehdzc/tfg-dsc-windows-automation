﻿Write-Host "Estableciendo la configuración de seguridad para el servidor NFS:"
Write-Host "  - Deshabilitar protocolos inseguros."
Write-Host "  - Definir los protocolos de transporte."
#Write-Host "  - Limitar el acceso a los recurso compartidos por usuario UNIX no asignados."
#Write-Host "  - Configurar los protocolos de autenticación para los recursos compartidos."

#Habilitar NFSv4 y deshabilitar protocolos NFSv2 y NFSv3. NFSv3 es necesario para el funcionamiento de NFS en clientes Windows
Set-NfsServerConfiguration -nfsv4 1 -Confirm:$false
Set-NfsServerConfiguration -nfsv2 0 -Confirm:$false
#Set-NfsServerConfiguration -nfsv3 0 -Confirm:$false

#Establecer la configuración de transporte para cada uno de los protocolos
Set-NfsServerConfiguration -MountProtocol TCP -Confirm:$false
Set-NfsServerConfiguration -MapServerProtocol TCP -Confirm:$false
Set-NfsServerConfiguration -Nfsprotocol TCP -Confirm:$false
Set-NfsServerConfiguration -NisProtocol TCP -Confirm:$false
Set-NfsServerConfiguration -NlmProtocol TCP -Confirm:$false
Set-NfsServerConfiguration -NsmProtocol TCP -Confirm:$false
Set-NfsServerConfiguration -PortmapProtocol TCP -Confirm:$false

#Obtener todos los recursos NFS compartidos y modificar la configuración para inhabilitar que los usuarios UNIX no asignados accedan al recurso compartido utilizando un UID o GID y establecer los protocolos de autenticación
<#
$shares = (Get-NfsShare | Where-Object -Property Name -NotLike *$).Name
foreach ($i in $shares) {
	Set-NfsShare -Name $i -EnableUnmappedAccess 0 -Confirm:$false
	Set-NfsShare -Name $i -Authentication Krb5,Krb5i,Krb5p -Confirm:$false
}
#>

#Reinicio del servicio de NFS para aplicar los cambios
Write-Host "Reiniciando el servicio NFS para aplicar los cambios..."
Restart-Service -Name NfsService | Out-Null