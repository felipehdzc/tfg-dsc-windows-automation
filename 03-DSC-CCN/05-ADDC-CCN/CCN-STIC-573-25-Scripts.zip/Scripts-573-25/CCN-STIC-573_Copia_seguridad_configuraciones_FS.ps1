﻿#Creación de variables de control
$fechafichero = Get-Date -Format "yyyy-MM-dd"
$horafichero = Get-Date -Format "HH.mm"

Set-Content -Value "" C:\Scripts\CCN-STIC-573A23_SMBServerConfiguration_$fechafichero`_$horafichero.txt
$ficheroserverconfiguration = "C:\Scripts\CCN-STIC-573A23_SMBServerConfiguration_$fechafichero`_$horafichero.txt"
Clear-Content $ficheroserverconfiguration

Set-Content -Value "" C:\Scripts\CCN-STIC-573A23_SMBClientConfiguration_$fechafichero`_$horafichero.txt
$ficheroclientconfiguration = "C:\Scripts\CCN-STIC-573A23_SMBClientConfiguration_$fechafichero`_$horafichero.txt"
Clear-Content $ficheroclientconfiguration

Set-Content -Value "" C:\Scripts\CCN-STIC-573A23_SMBShare_$fechafichero`_$horafichero.txt
$ficherosmbshare = "C:\Scripts\CCN-STIC-573A23_SMBShare_$fechafichero`_$horafichero.txt"
Clear-Content $ficherosmbshare

#Obtener un fichero de configuraciones del servidor de ficheros, tanto de su lado servidor como de su lado cliente y de los recursos compartidos
Write-Host "Obteniendo configuración de seguridad aplicada en el Servidor de Ficheros (lado servidor)..."
Get-SmbServerConfiguration | Select-Object * | Out-File $ficheroserverconfiguration
Write-Host " "
Write-Host "Puede consultar un registro de las configuraciones obtenidas del lado servidor en el fichero codificado como:" -NoNewline
Write-Host " CCN-STIC-573A23_SMBServerConfiguration_YYYY-MM-DD_HH.MM.txt" -NoNewline -ForegroundColor Green
Write-Host " ubicado en" -NoNewline
Write-Host " C:\Scripts" -NoNewline -ForegroundColor Green
Write-Host " "

Write-Host "Obteniendo configuración de seguridad aplicada en el Servidor de Ficheros (lado cliente)..."
Get-SmbClientConfiguration | Select-Object * | Out-File $ficheroclientconfiguration
Write-Host " "
Write-Host "Puede consultar un registro de las configuraciones obtenidas del lado cliente en el fichero codificado como:" -NoNewline
Write-Host " CCN-STIC-573A23_SMBClientConfiguration_YYYY-MM-DD_HH.MM.txt" -NoNewline -ForegroundColor Green
Write-Host " ubicado en" -NoNewline
Write-Host " C:\Scripts" -NoNewline -ForegroundColor Green
Write-Host " "

Write-Host "Obteniendo configuración de los recursos compartidos..."
Get-SmbShare | Select-Object * | Out-File $ficherosmbshare
Write-Host " "
Write-Host "Puede consultar un registro de los parámetro de los recursos compartidos en el fichero codificado como:" -NoNewline
Write-Host " CCN-STIC-573A23_SMBShare_YYYY-MM-DD_HH.MM.txt" -NoNewline -ForegroundColor Green
Write-Host " ubicado en" -NoNewline
Write-Host " C:\Scripts" -NoNewline -ForegroundColor Green
Write-Host " "