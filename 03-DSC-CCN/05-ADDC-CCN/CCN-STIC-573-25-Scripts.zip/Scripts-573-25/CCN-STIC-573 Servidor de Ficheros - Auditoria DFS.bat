@echo off
cls
@echo -----------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Auditoria DFS
@echo -----------------------------------------------------------
@echo.
@echo  Este script tiene como establece las configuraciones de auditoria
@echo  para un equipo bajo el rol de Servidor de Ficheros que utiliza 
@echo  el rol de servicios DFS para compartir archivos.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros
@echo  y scripts se encuentran en el directorio "C:\Scripts".
@echo.
@echo -----------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Habilitar_Auditoria_DFS.ps1
@echo off

@echo ----------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Auditoria DFS : EJECUCION FINALIZADA 
@echo ----------------------------------------------------------------------------------
pause
cls
