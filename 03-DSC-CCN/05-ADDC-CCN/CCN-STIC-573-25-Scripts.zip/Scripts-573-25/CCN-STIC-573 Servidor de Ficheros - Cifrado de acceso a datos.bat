@echo off
cls
@echo -----------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Cifrado de acceso a datos y red
@echo -----------------------------------------------------------------------------
@echo.
@echo  Este script tiene como objetivo habilitar el cifrado de acceso a datos para los
@echo  recursos compartidos con la intencion de asegurar los datos frente a un acceso
@echo  no autorizado mientras se transfieren archivos al recurso o desde el.
@echo.
@echo  Por otro lado, se habilita la imposibilidad de que se permitan los accesos
@echo  no cifrados a nivel de red a los recursos compartidos del Servidor de Ficheros.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros y scripts se
@echo  encuentran en el directorio "C:\Scripts".
@echo.
@echo -----------------------------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Habilitar_Cifrado_de_acceso_a_datos_y_cifrado_red.ps1
@echo off

@echo ----------------------------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Cifrado de acceso a datos y red : EJECUCION FINALIZADA
@echo ----------------------------------------------------------------------------------------------------
pause
cls
