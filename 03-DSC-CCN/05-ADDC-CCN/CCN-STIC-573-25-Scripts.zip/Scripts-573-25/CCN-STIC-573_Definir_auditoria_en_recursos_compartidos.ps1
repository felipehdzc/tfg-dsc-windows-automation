﻿#Trasladar el SID del grupo "Todos" para obtener el atributo "Name" independientemente del idioma del sistema operativo
$everyoneSid= New-Object System.Security.Principal.SecurityIdentifier "S-1-1-0"
$everyoneSidName= $everyoneSid.Translate([System.Security.Principal.NTAccount])
$everyoneSidName.Value

#Obtener recursos compatidos no administrativos
$shares = (Get-SmbShare | Where-Object -Property Name -NotLike *$).Path

#Listar recursos compartidos a modificar y advertencia antes de la ejecución
$showshares = (Get-SmbShare | Where-Object -Property Name -NotLike *$).Path
Write-Host "A continuación se establecerá la auditoría para el grupo 'Todos' en los siguientes recursos compartidos del servidor."
Write-Host "--------------------"
Write-Host "Recursos compartidos"
Write-Host ""
foreach ($i in $showshares) {
    if ($i.Length -ne 0) {
        Write-Host " - $i"
    }
}
Write-Host "--------------------"
Write-Host "No se eliminarán las entradas de auditoría ya creadas."
Write-Host ""
Write-Host "Nota: Si desea cancelar el proceso pulse 'Ctrl+C'." -ForegroundColor DarkYellow
pause

#Por cada recurso compartido se agrega a la entidad de seguridad "Todos" sin eliminar otras entradas de auditoría ya existentes
foreach ($i in $shares) {
    $path = $i
    $AuditUser = $everyoneSidName.Value
    $AuditRules = "DeleteSubdirectoriesAndFiles, Modify, ChangePermissions, TakeOwnership"
    $InheritType = "ContainerInherit,ObjectInherit"
    $AuditType = "Success, Failure"
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAuditRule($AuditUser,$AuditRules,$InheritType,"None",$AuditType)
    $ACL = get-acl $path -Audit
    $ACL.AddAuditRule($AccessRule)
    $ACL | Set-Acl $path
}