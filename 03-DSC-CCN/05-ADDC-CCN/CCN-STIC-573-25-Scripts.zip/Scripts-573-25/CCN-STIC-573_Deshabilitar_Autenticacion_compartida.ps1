﻿#Deshabilitar la autenticación compartida para usuarios
Write-Host "Deshabilitando la autenticación compartida..."
Set-SmbServerConfiguration -EnableAuthenticateUserSharing:$false -Confirm:$false