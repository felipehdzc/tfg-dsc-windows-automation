@echo off
cls
@echo ---------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Asistencia de acceso denegado
@echo ---------------------------------------------------------------------------
@echo.
@echo  Este script tiene como objetivo deshabilitar la asistencia frente a un acceso
@echo  denegado en el Servidor de Ficheros con la intencion de ofrecer la minima
@echo  informacion ante un acceso no autorizado.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros y scripts se 
@echo  encuentran en el directorio "C:\Scripts".
@echo.
@echo ---------------------------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Deshabilitar_Informacion_y_asistencia_acceso_denegado.ps1
@echo off

@echo --------------------------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Asistencia de acceso denegado : EJECUCION FINALIZADA 
@echo --------------------------------------------------------------------------------------------------
pause
cls
