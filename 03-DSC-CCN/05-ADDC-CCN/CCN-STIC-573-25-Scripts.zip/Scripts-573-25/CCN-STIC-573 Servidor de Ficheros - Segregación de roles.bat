@echo off
cls
@echo ------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Segregacion de roles
@echo ------------------------------------------------------------------
@echo.
@echo  Este script crea los siguientes grupos si no existen:
@echo      - Administradores FS
@echo      - Auditores FS
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros y
@echo  scripts se encuentran en el directorio "C:\Scripts".
@echo.
@echo ------------------------------------------------------------------
@echo.
pause

@echo Se crea el grupo de usuarios con capacidad para administrar Servidores de Ficheros
@echo on
net group /add "Administradores FS" /comment:"Grupo de usuarios sobre el que se delega la capacidad de administracion para Servidores de Ficheros" /domain
@echo off

@echo Se crea el grupo de usuarios con capacidad de administrar la auditoria de recursos compartidos
@echo on
net group /add "Auditores FS" /comment:"Grupo de usuarios con permisos de gestion de auditoria para Servidores de Ficheros" /domain
@echo off

@echo.
@echo -----------------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Segregacion de roles : EJECUCION FINALIZADA
@echo -----------------------------------------------------------------------------------------
pause
cls