﻿#Comprobar que el rol de NFS (FS-NFS-Service y RSAT-NFS-Admin) está instalado para ejecutar los scripts asociados a NFS
$estadoNFSRole = (Get-WindowsFeature -Name FS-NFS-Service).Installed
#$estadoNFSRSAT = (Get-WindowsFeature -Name RSAT-NFS-Admin).Installed

#Comprobar que el rol de DFS (FS-DFS-Namespace y RSAT-DFS-Mgmt-Con) está instalado para ejecutar los scripts asociados a DFS
$estadoDFSRole = (Get-WindowsFeature -Name FS-NFS-Service).Installed
#$estadoNFSRSAT = (Get-WindowsFeature -Name RSAT-DFS-Mgmt-Con).Installed

#Comprobar que el rol de BranchCache (FS-BranchCache y BranchCache) está instalado para ejecutar los scripts asociados a BranchCache para archivos de red
$estadoBCRole = (Get-WindowsFeature -Name FS-BranchCache).Installed

#Ejecutar los scripts correspondientes según roles instalados
if ($estadoNFSRole -eq $true) {
	#NFS (Estándar)
	&'.\CCN-STIC-573_Habilitar_Auditoria_Servidor_NFS.ps1'
	&'.\CCN-STIC-573_Configurar_Servidor_NFS.ps1'
	&'.\CCN-STIC-573_Configurar_Servidor_NFS_protocolos.ps1'
}

if ($estadoDFSRole -eq $true) {
	#DFS (Estándar)
	&'.\CCN-STIC-573_Habilitar_Auditoria_DFS.ps1'
}

if ($estadoBCRole -eq $true) {
	#BranchCache (Estándar)
	&'.\CCN-STIC-573_Configurar_BranchCache_para_archivos_de_red.ps1'
}