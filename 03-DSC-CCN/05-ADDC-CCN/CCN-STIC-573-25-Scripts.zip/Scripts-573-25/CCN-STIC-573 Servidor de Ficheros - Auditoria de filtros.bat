@echo off
cls
@echo ------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Auditoria de filtros
@echo ------------------------------------------------------------------
@echo.
@echo  Este script tiene como objetivo habilitar la auditoria de filtro con
@echo  la finalidad de que el Servidor de Ficheros pueda registrar la actividad
@echo  de filtrado de archivos en una base de datos de auditoria que se puede
@echo  revisar posteriormente ejecutando un informe de auditoria de archivos.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros y scripts
@echo  se encuentran en el directorio "C:\Scripts".
@echo.
@echo ------------------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Habilitar_Auditoria_de_filtros.ps1
@echo off

@echo --------------------------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Asistencia de acceso denegado : EJECUCION FINALIZADA 
@echo --------------------------------------------------------------------------------------------------
pause
cls
