@echo off
cls
@echo ----------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Autenticacion compartida
@echo ----------------------------------------------------------------------
@echo.
@echo  Este script tiene como objetivo inhabilitar la autenticacion compartida
@echo  para usuarios dentro del Servidor de Ficheros.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros y scripts
@echo  se encuentran en el directorio "C:\Scripts".
@echo.
@echo ----------------------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Deshabilitar_Autenticacion_compartida.ps1
@echo off

@echo ---------------------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Autenticacion compartida : EJECUCION FINALIZADA
@echo ---------------------------------------------------------------------------------------------
pause
cls
