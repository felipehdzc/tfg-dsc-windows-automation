@echo off
cls
@echo -----------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Auditoria NFS
@echo -----------------------------------------------------------
@echo.
@echo  Este script tiene como establece las configuraciones de auditoria
@echo  para un equipo bajo el rol de Servidor de Ficheros que utiliza el 
@echo  rol de Servidor NFS para compartir archivos.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros
@echo  y scripts se encuentran en el directorio "C:\Scripts".
@echo.
@echo -----------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Habilitar_Auditoria_Servidor_NFS.ps1
@echo off

@echo ----------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Auditoria NFS : EJECUCION FINALIZADA 
@echo ----------------------------------------------------------------------------------
pause
cls
