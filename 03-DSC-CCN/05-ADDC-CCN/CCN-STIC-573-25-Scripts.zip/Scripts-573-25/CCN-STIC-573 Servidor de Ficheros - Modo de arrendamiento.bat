@echo off
cls
@echo --------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Leasing y NameHardeningLevel
@echo --------------------------------------------------------------------------
@echo.
@echo  Este script tiene como objetivo activar y configurar el "Leasing Mode" de los
@echo  recursos compartidos para establecer una configuracion segura respecto al
@echo  protocolo SMB.
@echo.
@echo  Por otro lado tambien se define el nivel de seguridad del nombre del servicio SMB.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros y scripts se
@echo  encuentran en el directorio "C:\Scripts".
@echo.
@echo --------------------------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Configuracion_LeasingMode_y_NameHardeningLevel.ps1
@echo off

@echo -------------------------------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - Leasing y NameHardeningLevel : EJECUCION FINALIZADA 
@echo -------------------------------------------------------------------------------------------------
pause
cls
