@echo off
cls
@echo -------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - ABE
@echo -------------------------------------------------
@echo.
@echo  Este script tiene como objetivo habilitar la enumeracion 
@echo  basada en el acceso con la intencion de que solamente 
@echo  se muestren los archivos y carpetas para aquellos usuarios 
@echo  que tienen permisos de acceso. Si un usuario no tiene 
@echo  permisos de lectura (o equivalente) para una carpeta, 
@echo  Windows oculta la carpeta desde la vista del usuario.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros
@echo  y scripts se encuentran en el directorio "C:\Scripts".
@echo.
@echo -------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-573_Habilitar_Enumeracion_Basada_en_Acceso_ABE.ps1
@echo off

@echo ------------------------------------------------------------------------
@echo      CCN-STIC-573 Servidor de Ficheros - ABE : EJECUCION FINALIZADA 
@echo ------------------------------------------------------------------------
pause
cls
