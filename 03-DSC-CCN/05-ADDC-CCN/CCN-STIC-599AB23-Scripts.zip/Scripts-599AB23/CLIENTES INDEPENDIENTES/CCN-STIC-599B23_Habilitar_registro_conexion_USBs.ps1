﻿#Habilitar el registro de conexiones para dispositivos USB
$eventosusb = Get-WinEvent -ListLog 'Microsoft-Windows-DriverFrameworks-UserMode/Operational'
$eventosusb.IsEnabled = $true
$eventosusb.SaveChanges()