@echo off
cls
@echo ----------------------------------------------------------------
@echo          CCN-STIC-599B23 - Menu contextual Windows 11
@echo ----------------------------------------------------------------
@echo.
@echo  Este script permite configurar el antiguo menu contextual
@echo  utilizado por los sistemas operativos de Microsoft hasta
@echo  Windows 10.
@echo.
@echo  El script debe ejecutarse en el entorno del usuario que
@echo  desea cambiar el menu contextual, dado que la configuracion
@echo  se realiza por usuario.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros
@echo  y scripts se encuentran en el directorio "C:\Scripts".
@echo.
@echo -----------------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-599B23_Antiguo_menu_contextual.ps1
@echo off

@echo -------------------------------------------------------------------------
@echo   CCN-STIC-599B23 - Menu contextual Windows 11 : EJECUCION FINALIZADA 
@echo -------------------------------------------------------------------------
pause
cls
