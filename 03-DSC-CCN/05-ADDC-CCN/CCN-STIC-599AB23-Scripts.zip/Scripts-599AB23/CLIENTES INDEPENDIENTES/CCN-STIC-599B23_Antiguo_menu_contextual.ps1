Clear-Host
Write-Host ""
Write-Host "Configurando menu contextual de Windows 10..."
reg.exe add "HKCU\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32" /f /ve | Out-Null
taskkill /f /im explorer.exe | Out-Null
start explorer.exe | Out-Null
Write-Host ""
Write-Host "La configuraci�n ha finalizado, ahora dispone del menu contextual de Windows 10".