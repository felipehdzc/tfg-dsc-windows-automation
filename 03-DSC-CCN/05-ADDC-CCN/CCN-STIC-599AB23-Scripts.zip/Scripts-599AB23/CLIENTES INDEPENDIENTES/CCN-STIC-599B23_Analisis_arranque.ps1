﻿#Ejecutar análisis de los sectores de arranque y un análisis rápido
& 'C:\Program Files\Windows Defender\MpCmdRun.exe' -Scan -ScanType 1 -BootSectorScan
& 'C:\Program Files\Windows Defender\MpCmdRun.exe' -Scan -ScanType 1