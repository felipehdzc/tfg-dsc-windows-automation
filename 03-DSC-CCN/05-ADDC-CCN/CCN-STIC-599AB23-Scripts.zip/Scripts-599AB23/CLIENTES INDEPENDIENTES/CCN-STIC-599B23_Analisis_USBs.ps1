﻿Clear-Host

#Habilitar el registro de conexiones para dispositivos USB
$eventosusb = Get-WinEvent -ListLog 'Microsoft-Windows-DriverFrameworks-UserMode/Operational'
$eventosusb.IsEnabled = $true
$eventosusb.SaveChanges()

#Ejecutar análisis de dispositivo USB conectado
$unidadesexternasusb = gwmi win32_diskdrive | ?{$_.interfacetype -eq "USB"} | %{gwmi -Query "ASSOCIATORS OF {Win32_DiskDrive.DeviceID=`"$($_.DeviceID.replace('\','\\'))`"} WHERE AssocClass = Win32_DiskDriveToDiskPartition"} |  %{gwmi -Query "ASSOCIATORS OF {Win32_DiskPartition.DeviceID=`"$($_.DeviceID)`"} WHERE AssocClass = Win32_LogicalDiskToPartition"} | %{$_.deviceid}
foreach ($i in $unidadesexternasusb) {
    $letra = $i + "\"
    Write-Host "Se está analizando la unidad $letra, espere a que finalice el proceso."
    Start-Job -Name "Análisis unidad $letra" {& 'C:\Program Files\Windows Defender\MpCmdRun.exe' -Scan -ScanType 3 -File $letra}
}