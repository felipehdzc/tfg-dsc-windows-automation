$appname = @(
"*3DViewer*"
"*Advertising*"
"*Alarms*"
"*Bing*"
"*Camera*"
"*CandyCrush*"
"*Clipchamp*"
"*Comm*"
"*DesktopApp*"
"*DolbyAccess*"
"*FeedbackHub*"
"*Game*"
"*Gaming*"
"*GetHelp*"
"*Getstarted*"
"*Holographic*"
"*Maps*"
"*Mess*"
"*MixedReality*"
"*Office*"
"*OneConnect*"
"*OneNote*"
"*People*"
"*Phone*"
"*PowerAutomateDesktop*"
"*PPIProjection*"
"*Print3D*"
"*QuickAssist*"
"*screensk*"
"*Skype*"
"*SolitaireCollection*"
"*SoundRec*"
"*Sticky*"
"*Store*"
"*Wallet*"
"*Xbox*"
"*Zune*"
)

$winpack = @(
"*Hello-Face*"
"*MediaPlayer*"
"*QuickAssist*"
)

"Eliminando Appx"

ForEach($app in $appname){
Get-AppxPackage -AllUsers $app | Remove-AppxPackage -ErrorAction SilentlyContinue
}

"Eliminando Appx Provisioned"

ForEach($app in $appname){
Get-AppxProvisionedPackage -online | Where-Object {$_.packagename -like $app} | Remove-AppxProvisionedPackage -Online
}

"Eliminando paquetes de Windows"

ForEach($pack in $winpack){
Get-WindowsPackage -Online | Where PackageName -like $pack | Remove-WindowsPackage -Online -NoRestart -ErrorAction SilentlyContinue
}