@echo off
cls
@echo ------------------------------------------------------------------------
@echo           CCN-STIC-599B23 Cliente Independiente - Bitlocker
@echo ------------------------------------------------------------------------
@echo.
@echo  Este script modifica la configuracion de inicio de los servicios
@echo  requeridos para el uso de BitLocker y habilita las configuraciones
@echo  necesarias en las Plantillas Administrativas.
@echo.
@echo  Antes de ejecutar este script asegurese que los ficheros y scripts
@echo  se encuentran en el directorio 
@echo  "C:\Scripts\USO OFICIAL\Configuraciones Adicionales".
@echo.
@echo ------------------------------------------------------------------------

pause

set Plantilla="c:\Scripts\USO OFICIAL\Configuraciones Adicionales\CCN-STIC-599B23 Incremental Bitlocker.inf"

@echo.
@echo Configurando servicios de Windows...
@echo on
secedit /configure /quiet /db "c:\Scripts\USO OFICIAL\Configuraciones Adicionales\servicios_bitlocker.sdb" /cfg %Plantilla% /overwrite /log "c:\Scripts\USO OFICIAL\Configuraciones Adicionales\servicios_bitlocker.log"
@echo.
@echo Servicios de Windows configurados.
@echo off

c:
cd "c:\Scripts\USO OFICIAL\Configuraciones Adicionales"

@echo.
@echo Configurando Plantillas Administrativas...
@echo on
regedit.exe /s CCN-STIC-599B23_BitLocker.reg
@echo off

@echo.
@echo Plantillas Administrativas configuradas.
@echo.
@echo.
@echo ---------------------------------------------------------------------------------------
@echo        CCN-STIC-599B23 Cliente Independiente - Bitlocker : EJECUCION FINALIZADA 
@echo ---------------------------------------------------------------------------------------
pause
cls
