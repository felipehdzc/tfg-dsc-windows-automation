@echo off
cls
@echo ------------------------------------------------------------------
@echo    CCN-STIC-599B23 Cliente Independiente - Segregacion de roles
@echo ------------------------------------------------------------------
@echo.
@echo  Este script crea el siguiente grupo si no existe:
@echo      - Auditores
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros
@echo  y scripts se encuentran en el directorio "C:\Scripts".
@echo.
@echo ------------------------------------------------------------------
@echo.
pause

@echo Se crea el grupo de usuarios con capacidad para especificar opciones de auditoría de acceso a objetos
@echo on
net localgroup /add Auditores /comment:"Grupo de usuarios sobre el que se delega la posibilidad de establecer opciones de auditoria"
@echo off

@echo.
@echo -------------------------------------------------------------------------------------
@echo  CCN-STIC-599B23 Cliente Independiente - Segregacion de roles : EJECUCION FINALIZADA 
@echo -------------------------------------------------------------------------------------
pause
cls