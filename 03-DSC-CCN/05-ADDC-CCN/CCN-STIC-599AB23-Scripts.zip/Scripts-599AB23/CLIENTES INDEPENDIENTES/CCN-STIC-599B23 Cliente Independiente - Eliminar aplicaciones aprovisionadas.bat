@echo off
cls
@echo ------------------------------------------------------------------------
@echo    CCN-STIC-599B23 Cliente Independiente - Aplicaciones Aprovisionadas
@echo ------------------------------------------------------------------------
@echo.
@echo  Este script elimina las aplicaciones aprovisionadas y el resto de
@echo  appx instaladas innecesarias en el sistema.
@echo.
@echo  NOTA: Debera editar el script en caso de necesitar alguna appx
@echo  que ya estuviese instalada en el equipo. Si no edita dicho script
@echo  se eliminaran las aplicaciones aprovisionadas innecesarias del
@echo  sistema Windows Cliente.
@echo.
@echo --------------------------------------------------------------------
@echo.
pause
@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-599B23_Eliminar_aplicaciones_aprovisionadas.ps1
@echo off
@echo.
@echo ---------------------------------------------------------------------------------------------
@echo   CCN-STIC-599B23 Cliente Independiente - Aplicaciones Aprovisionadas: Ejecucion finalizada
@echo ---------------------------------------------------------------------------------------------
@echo.
pause
