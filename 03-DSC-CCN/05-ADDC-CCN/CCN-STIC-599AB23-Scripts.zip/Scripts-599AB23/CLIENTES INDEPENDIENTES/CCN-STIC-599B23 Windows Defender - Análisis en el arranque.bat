@echo off
cls
@echo ----------------------------------------------------------------
@echo    CCN-STIC-599B23 Windows Defender - Analisis en el arranque
@echo ----------------------------------------------------------------
@echo.
@echo  Este script tiene como objetivo realizar las acciones 
@echo  necesarias para que un sistema operativo Windows sea capaz
@echo  de realizar un analisis en el arranque de este.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros
@echo  y scripts se encuentran en el directorio "C:\Scripts".
@echo.
@echo ------------------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
@echo.
@echo  A continuacion, se copiaran los ficheros necesarios para realizar
@echo  las labores de analisis en el arranque, asi como la creacion
@echo  de configuraciones en el equipo para su correspondiente ejecucion.
@echo.
@echo  Nota: Si desea cancelar el proceso pulse 'Ctrl+C
@echo off
pause
@echo on
xcopy /hy CCN-STIC-599B23_Analisis_arranque.ps1 C:\Windows\
schtasks.exe /create /xml C:\Scripts\CCN-STIC-599B23_Analisis_arranque_OS.xml /TN "Analisis arranque OS"
@echo off

@echo ---------------------------------------------------------------------------------------
@echo    CCN-STIC-599B23 Windows Defender - Analisis en el arranque : EJECUCION FINALIZADA 
@echo ---------------------------------------------------------------------------------------
pause
cls
