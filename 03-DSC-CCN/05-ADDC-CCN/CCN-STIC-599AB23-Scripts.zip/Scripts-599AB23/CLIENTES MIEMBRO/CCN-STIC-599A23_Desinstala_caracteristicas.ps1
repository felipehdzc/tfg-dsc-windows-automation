Clear-Host

#Verbose
$verbose = $false

#Conjunto de caracter�sticas necesarias que van a mantenerse tras la ejecuci�n del script
$mantener_caracteristica = @(
    "Client-DeviceLockdown",#no instalado por defecto
    "Client-KeyboardFilter",#no instalado por defecto
    "Client-UnifiedWriteFilter",#no instalado por defecto
    "Windows-Defender-ApplicationGuard",#no instalado por defecto
    "WorkFolders-Client",#por defecto
    "SmbDirect",#por defecto
    "MSRDC-Infraestructure",#por defecto
    "SearchEngine-Client-Package",#por defecto
    "Windows-Defender-Default-Definitions",#por defecto
    "Printing-PrintToPDFServices-Features",#por defecto
    "MicrosoftWindowsPowerShellV2Root",#por defecto
    "MicrosoftWindowsPowerShellV2",#por defecto
    "NetFx4-AdvSrvs",#por defecto
    "Internet-Explorer-Optional-amd64"#por defecto
)

#Obtiene la lista de caracteristicas del sistema
# (tanto habilitadas como no habilitadas)
$c_todas = dism /online /format:list /get-features

#Recorre la lista extrayendo las caracteristicas habilitadas
$c_hab = @()
for ( $i=0; $i -lt $c_todas.length; $i++ )
{
   #Si la caracteristica esta habilitada, la anyade a la lista
   if ( $c_todas[$i] | select-string "^Nombre de carac" ) {
      if ( $c_todas[$i+1] | select-string "^Estado : Habilitado" ) {
		$tmp = $c_todas[$i] -split "^Nombre de caracter�stica : "
        if ($verbose) { Write-Host "Caracteristica habilitada:" $tmp[1]}
        $c_hab = $c_hab + $tmp[1]  
		$i++
	  }
   }
}

#Si la caracteristica esta en la lista de excluidos, la elimina de la lista
$c_fin = @()
foreach ( $i in $c_hab ) {
    if ($mantener_caracteristica -notcontains $i) {
    $c_fin = $c_fin + $i
    }
}

#Lista las caracteristicas habilitadas
Write-Host �Lista de caracteristicas que se procede a deshabilitar:"
Write-Host � "
Write-Host �========================================================="
$c_fin
Write-Host �========================================================="
Write-Host � "

#Muestra un mensaje de aviso
Write-Host "A continuaci�n se desinstalar�n todas las caracter�sticas que no sean necesarias"
Write-Host "en un equipo de tipo Cliente Miembro o que hayan sido determinados en el presente script."
Write-Host "Nota: Si desea cancelar el proceso pulse 'Ctrl+C'" -ForegroundColor DarkYellow
Write-Host � "
pause
Write-Host � "

#Deshabilita todas las caracteristicas habilitadas innecesarias
foreach ( $i in $c_fin ) {
    Write-Host "Deshabilitando caracteristica: $i"
    dism /online /disable-feature /FeatureName:$i /norestart /quiet
    }

#Reinicia el equipo para completar la desactivacion de las caracteristicas
Write-Host � "
Write-Host "A continuacion se reiniciara el sistema para completar la desactivacion de las caracteristicas." -ForegroundColor DarkYellow
pause
shutdown /r /t 15 /c "El sistema se reiniciara en 15 segundos."
