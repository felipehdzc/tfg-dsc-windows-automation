@echo off
cls
@echo ----------------------------------------------------------------
@echo    CCN-STIC-599A23 Windows Defender - Analisis de integridad
@echo ----------------------------------------------------------------
@echo.
@echo  Este script tiene como objetivo realizar las acciones 
@echo  necesarias para que un sistema operativo Windows sea capaz
@echo  de realizar un analisis de la integridad de funciones
@echo  criticas.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros
@echo  y scripts se encuentran en el directorio "C:\Scripts".
@echo.
@echo ------------------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
@echo.
@echo  A continuacion, se copiaran los ficheros necesarios para realizar
@echo  las labores de analisis de integridad, asi como la creacion
@echo  de configuraciones en el equipo para su correspondiente ejecucion.
@echo.
@echo  Nota: Si desea cancelar el proceso pulse 'Ctrl+C
@echo off
pause
@echo on
schtasks.exe /create /xml C:\Scripts\CCN-STIC-599A23_Integridad_ficheros.xml /TN "Analisis integridad ficheros"
@echo off

@echo ---------------------------------------------------------------------------------------
@echo    CCN-STIC-599A23 Windows Defender - Analisis de integridad : EJECUCION FINALIZADA 
@echo ---------------------------------------------------------------------------------------
pause
cls
