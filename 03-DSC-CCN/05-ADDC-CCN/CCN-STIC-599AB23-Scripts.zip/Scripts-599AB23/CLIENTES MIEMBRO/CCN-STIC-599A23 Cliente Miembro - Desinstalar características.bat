@echo off
cls
@echo -----------------------------------------------------------------
@echo    CCN-STIC-599A23 Cliente Miembro - Caracteristicas
@echo -----------------------------------------------------------------
@echo.
@echo  Este script desinstala del cliente todos las caracteristicas 
@echo  que este tenga instaladas y no sean necesarias, teniendo en
@echo  consideracion las necesidades de la organizacion.
@echo.
@echo  Antes de ejecutar este script debe asegurarse que los ficheros
@echo  y scripts se encuentran en el directorio "C:\Scripts".
@echo.
@echo ------------------------------------------------------------------
@echo.
pause

@echo off
c:
cd c:\scripts
@echo on
powershell.exe -executionpolicy RemoteSigned -File CCN-STIC-599A23_Desinstala_caracteristicas.ps1
@echo off

@echo --------------------------------------------------------------------------------------
@echo   CCN-STIC-599A23 Cliente Miembro - Caracteristicas : EJECUCION FINALIZADA 
@echo --------------------------------------------------------------------------------------
pause
cls
